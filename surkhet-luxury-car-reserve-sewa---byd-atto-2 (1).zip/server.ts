import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { DEFAULT_RATES, calculatePrice } from './src/utils/pricing.ts';
import { BookingItem, GalleryPhoto, ServiceRates, BusinessSettings } from './src/types/index.ts';
import { saveBookingToSupabase, testSupabaseConnection, SUPABASE_PROJECT_ID } from './src/services/supabase.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Database file setup
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface DatabaseSchema {
  admin: {
    username: string;
    passwordHash: string;
    salt: string;
    isConfigured: boolean;
  };
  activeSlot: {
    username: string | null;
    token: string | null;
    expiresAt: number | null;
  };
  rates: ServiceRates;
  gallery: GalleryPhoto[];
  bookings: BookingItem[];
  settings: BusinessSettings;
}

// Simple secure hashing
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
}

const defaultSalt = 'surkhet_luxury_salt_2026';

const initialDatabase: DatabaseSchema = {
  admin: {
    username: '',
    passwordHash: '',
    salt: '',
    isConfigured: false,
  },
  activeSlot: {
    username: null,
    token: null,
    expiresAt: null,
  },
  rates: { ...DEFAULT_RATES },
  gallery: [
    {
      id: 'byd-1',
      title: 'BYD ATTO 2 - Scenic Surkhet Valley',
      category: 'exterior',
      imageUrl: '/src/assets/images/byd_atto_2_hero_1790175652304.jpg',
      caption: 'BYD ATTO 2 Luxury Electric SUV in scenic Surkhet valley hills at sunset',
      isBydAtto2: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'byd-2',
      title: 'BYD ATTO 2 - Front Aerodynamic Fascia',
      category: 'exterior',
      imageUrl: '/src/assets/images/byd_atto_2_front_1790175668365.jpg',
      caption: 'Sleek crystal LED headlights, signature sealed EV grille, and sculpted front profile',
      isBydAtto2: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'byd-3',
      title: 'BYD ATTO 2 - Executive Cockpit & Touchscreen',
      category: 'interior',
      imageUrl: '/src/assets/images/byd_atto_2_interior_1790175686582.jpg',
      caption: 'Rotatable intelligent touchscreen, luxury ergonomic vegan leather seats, and ambient lighting',
      isBydAtto2: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'byd-4',
      title: 'BYD ATTO 2 - Continuous LED Taillight Bar',
      category: 'exterior',
      imageUrl: '/src/assets/images/byd_atto_2_rear_1790175706520.jpg',
      caption: 'Aerodynamic rear spoiler, continuous dynamic LED taillight bar, and high ground clearance',
      isBydAtto2: true,
      createdAt: new Date().toISOString(),
    },
  ],
  bookings: [
    {
      id: 'b-demo-1',
      referenceId: 'SUR-1001',
      customerName: 'रमेश अधिकारी (Ramesh Adhikari)',
      customerPhone: '9858012345',
      customerEmail: 'ramesh.surkhet@gmail.com',
      serviceId: 'surkhet-nepalgunj',
      serviceName: 'सुर्खेत → नेपालगन्ज',
      tripType: 'Two Way (दोहोरो यात्रा)',
      routePlan: 'two-way',
      pickupDate: '2026-09-25',
      pickupTime: '08:00 AM',
      pickupLocation: 'Birendranagar-6, Surkhet',
      dropLocation: 'Tribhuvan Chowk, Nepalgunj',
      passengerCount: 3,
      specialRequests: 'AC on during the whole trip',
      amount: 8000,
      status: 'confirmed',
      createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
      adminNotes: 'Confirmed with driver. Advised customer on 8 AM start.',
    },
    {
      id: 'b-demo-2',
      referenceId: 'SUR-1002',
      customerName: 'सरिता खड्का (Sarita Khadka)',
      customerPhone: '9848098765',
      customerEmail: 'sarita.k@outlook.com',
      serviceId: 'airport-pickup-drop',
      serviceName: 'सुर्खेत विमानस्थल पिकअप र ड्रप',
      tripType: 'Pickup & Drop',
      pickupDate: '2026-09-24',
      pickupTime: '01:30 PM',
      pickupLocation: 'Surkhet Airport (SKH)',
      dropLocation: 'Hotel Subh Hotel, Birendranagar',
      passengerCount: 2,
      specialRequests: 'Buddha Air flight U4 133',
      amount: 1000,
      status: 'pending',
      createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    },
  ],
  settings: {
    businessNameNepali: 'सुर्खेत लक्जरी कार रिजर्भ सेवा',
    businessNameEnglish: 'SURKHET LUXURY CAR RESERVE SEWA',
    phone: '9802581402',
    altPhone: '9802581402',
    email: 'info@surkhetluxurycar.com',
    address: 'वीरेन्द्रनगर, सुर्खेत',
    whatsapp: '9802581402',
    facebookUrl: 'https://facebook.com',
    tiktokUrl: 'https://tiktok.com',
    instagramUrl: 'https://instagram.com',
    tagline: 'कर्णालीको पहिलो १००% विद्युतीय प्रिमियम BYD ATTO 2 लक्जरी कार सेवा',
  },
};

function readDb(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDatabase, null, 2), 'utf-8');
      return initialDatabase;
    }
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return {
      ...initialDatabase,
      ...parsed,
      rates: { ...DEFAULT_RATES, ...(parsed.rates || {}) },
    };
  } catch (err) {
    console.error('Error reading DB, using memory fallback:', err);
    return initialDatabase;
  }
}

function writeDb(data: DatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing DB:', err);
  }
}

// Authentication Middleware
function authenticateAdmin(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ success: false, error: 'Unauthorized: Missing or invalid token' });
    return;
  }

  const token = authHeader.split(' ')[1];
  const db = readDb();

  if (
    !db.activeSlot.token ||
    db.activeSlot.token !== token ||
    !db.activeSlot.expiresAt ||
    db.activeSlot.expiresAt < Date.now()
  ) {
    res.status(401).json({ success: false, error: 'Session expired or invalid. Please login again.' });
    return;
  }

  // Extend session on activity (1 hour)
  db.activeSlot.expiresAt = Date.now() + 3600000;
  writeDb(db);

  (req as any).adminUser = db.activeSlot.username;
  next();
}

// API Routes

// Public rates
app.get('/api/rates', (_req: Request, res: Response) => {
  const db = readDb();
  res.json({ success: true, rates: db.rates });
});

// Public gallery (BYD ATTO 2 photos only)
app.get('/api/gallery', (_req: Request, res: Response) => {
  const db = readDb();
  res.json({ success: true, gallery: db.gallery });
});

// Public business settings
app.get('/api/settings', (_req: Request, res: Response) => {
  const db = readDb();
  res.json({ success: true, settings: db.settings });
});

// Public Booking Submission with server-side validation
app.post('/api/bookings', (req: Request, res: Response) => {
  try {
    const {
      customerName,
      customerPhone,
      customerEmail,
      serviceId,
      routePlan,
      numberOfDays,
      pickupDate,
      pickupTime,
      pickupLocation,
      dropLocation,
      passengerCount,
      specialRequests,
    } = req.body;

    if (!customerName || !customerPhone || !serviceId || !pickupDate || !pickupLocation) {
      res.status(400).json({
        success: false,
        error: 'कृपया सबै आवश्यक विवरणहरू भर्नुहोस् (Missing required booking fields)',
      });
      return;
    }

    const db = readDb();

    // Centralized server-side price calculation
    const pricing = calculatePrice(serviceId, {
      plan: routePlan,
      days: numberOfDays,
      rates: db.rates,
    });

    if (!pricing.isValid || pricing.amount === null) {
      res.status(400).json({
        success: false,
        error: pricing.message || 'अमान्य सेवा वा विकल्पहरू (Invalid service selection)',
      });
      return;
    }

    const refNumber = Math.floor(1000 + Math.random() * 9000);
    const newBooking: BookingItem = {
      id: 'b-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      referenceId: `SUR-${refNumber}`,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail ? customerEmail.trim() : undefined,
      serviceId,
      serviceName: pricing.serviceTitleNepali,
      tripType: pricing.tripType,
      routePlan,
      numberOfDays: numberOfDays ? Number(numberOfDays) : undefined,
      pickupDate,
      pickupTime: pickupTime || 'As scheduled',
      pickupLocation: pickupLocation.trim(),
      dropLocation: dropLocation ? dropLocation.trim() : 'As per plan',
      passengerCount: Math.min(4, Math.max(1, Number(passengerCount) || 1)),
      specialRequests: specialRequests ? specialRequests.trim() : undefined,
      amount: pricing.amount, // Server verified numeric amount!
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    db.bookings.unshift(newBooking);
    writeDb(db);

    // Persist to Supabase Backend
    saveBookingToSupabase(newBooking)
      .then((supaRes) => {
        if (supaRes.success) {
          console.log(`[Supabase] Booking ${newBooking.referenceId} synced to Supabase table '${supaRes.tableUsed}'`);
        } else {
          console.log(`[Supabase Note] Sync attempt: ${supaRes.error}`);
        }
      })
      .catch((err) => {
        console.warn(`[Supabase Error] ${err?.message || err}`);
      });

    res.status(201).json({
      success: true,
      booking: newBooking,
      pricing,
      supabaseProject: SUPABASE_PROJECT_ID,
      message: 'बुकिङ सफलतापूर्वक पेश भयो (Booking submitted successfully)',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Internal server error' });
  }
});

// Admin Supabase Status
app.get('/api/admin/supabase-status', async (_req: Request, res: Response) => {
  try {
    const status = await testSupabaseConnection();
    res.json({ success: true, status });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to check Supabase' });
  }
});

// Admin Supabase Sync All Bookings
app.post('/api/admin/supabase-sync', async (req: Request, res: Response) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const db = readDb();
  if (!token || !db.activeSlot.token || db.activeSlot.token !== token) {
    res.status(401).json({ success: false, error: 'Unauthorized' });
    return;
  }

  const results = [];
  for (const b of db.bookings) {
    const r = await saveBookingToSupabase(b);
    results.push({ id: b.id, referenceId: b.referenceId, ...r });
  }

  res.json({
    success: true,
    totalBookings: db.bookings.length,
    results,
    message: `${results.length} bookings processed for Supabase sync`,
  });
});

// Admin Setup Status
app.all(['/api/admin/setup-status', '/api/admin/setup_status'], (_req: Request, res: Response) => {
  const db = readDb();
  res.json({
    success: true,
    isConfigured: db.admin.isConfigured,
    hasActiveSlot: !!(db.activeSlot.token && db.activeSlot.expiresAt && db.activeSlot.expiresAt > Date.now()),
    activeUser: db.activeSlot.username,
  });
});

// Admin Setup (Initial Single-Slot Registration)
app.post('/api/admin/setup', (req: Request, res: Response) => {
  const db = readDb();

  // Strict Single Slot Enforcement: If an admin is already configured, completely disallow any new registration!
  if (db.admin && db.admin.isConfigured) {
    res.status(403).json({
      success: false,
      error: 'व्यवस्थापक खाता पहिल्यै दर्ता भइसकेको छ। अर्को नयाँ खाता बनाउने अनुमति छैन। (Admin account is already created and locked. Only one admin account is allowed.)',
    });
    return;
  }

  const { username, password } = req.body;
  if (!username || !username.trim() || !password || password.length < 5) {
    res.status(400).json({
      success: false,
      error: 'युजरनेम र कम्तीमा ५ क्यारेक्टर लामो पासवर्ड अनिवार्य छ (Username and minimum 5-character password required)',
    });
    return;
  }

  const salt = crypto.randomBytes(16).toString('hex');
  const passwordHash = hashPassword(password, salt);

  // Lock the slot permanently to this admin
  db.admin = {
    username: username.trim(),
    passwordHash,
    salt,
    isConfigured: true,
  };

  // Automatically start an active session for the newly registered admin
  const now = Date.now();
  const token = 'sat_' + crypto.randomBytes(32).toString('hex');
  db.activeSlot = {
    username: username.trim(),
    token,
    expiresAt: now + 3600000 * 4, // 4 hours active
  };
  writeDb(db);

  res.status(201).json({
    success: true,
    token,
    username: username.trim(),
    message: 'व्यवस्थापक खाता सफलतापूर्वक सिर्जना भयो र लगइन गरियो। (Admin account created and logged in successfully.)',
  });
});

// Admin Login with Single-Slot Security
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { username, password, forceResetSlot } = req.body;
  const db = readDb();

  // If admin has not been created yet, instruct the user to use the open slot to register
  if (!db.admin || !db.admin.isConfigured) {
    res.status(400).json({
      success: false,
      needsSetup: true,
      error: 'व्यवस्थापक खाता अझै सिर्जना भएको छैन। कृपया १ उपलब्ध स्लट प्रयोग गरी आफ्नो खाता सिर्जना गर्नुहोस्। (Admin account not created yet. Please sign up using the single open slot.)',
    });
    return;
  }

  if (!username || !password) {
    res.status(400).json({ success: false, error: 'Username and password are required' });
    return;
  }

  // Check password strictly against the admin credentials created in the single slot
  const enteredHash = hashPassword(password, db.admin.salt);
  const isValid =
    username.trim().toLowerCase() === db.admin.username.toLowerCase() &&
    enteredHash === db.admin.passwordHash;

  if (!isValid) {
    res.status(401).json({ success: false, error: 'गलत युजरनेम वा पासवर्ड (Invalid username or password)' });
    return;
  }

  // Single Admin Slot check
  const now = Date.now();
  const hasActiveSlot =
    db.activeSlot.token &&
    db.activeSlot.expiresAt &&
    db.activeSlot.expiresAt > now;

  if (hasActiveSlot && !forceResetSlot) {
    res.status(403).json({
      success: false,
      slotLocked: true,
      error: 'Single Admin Slot हाल अर्को सेसनमा सक्रिय छ। यदि यो तपाईंको पुरानो सेसन हो भने स्लट रिसेट गर्न सक्नुहुन्छ।',
    });
    return;
  }

  // Generate new session token
  const token = 'sat_' + crypto.randomBytes(32).toString('hex');
  db.activeSlot = {
    username: username.trim(),
    token,
    expiresAt: now + 3600000 * 4, // 4 hours active
  };
  writeDb(db);

  res.json({
    success: true,
    token,
    username: username.trim(),
    message: 'Login successful',
  });
});

// Admin Reset Slot
app.post('/api/admin/reset-slot', (req: Request, res: Response) => {
  const { password } = req.body;
  const db = readDb();

  if (db.admin && db.admin.isConfigured) {
    if (!password) {
      res.status(400).json({ success: false, error: 'Password required to reset active slot' });
      return;
    }
    const enteredHash = hashPassword(password, db.admin.salt);
    const isValid = enteredHash === db.admin.passwordHash;
    if (!isValid) {
      res.status(401).json({ success: false, error: 'स्लट रिसेट गर्न पासवर्ड मिलेन (Incorrect password to reset slot)' });
      return;
    }
  }

  db.activeSlot = {
    username: null,
    token: null,
    expiresAt: null,
  };
  writeDb(db);

  res.json({ success: true, message: 'Admin slot successfully released and reset' });
});

// Admin Logout
app.post('/api/admin/logout', (req: Request, res: Response) => {
  const db = readDb();
  db.activeSlot = {
    username: null,
    token: null,
    expiresAt: null,
  };
  writeDb(db);
  res.json({ success: true, message: 'Logged out successfully' });
});

// Admin Me
app.get('/api/admin/me', authenticateAdmin, (req: Request, res: Response) => {
  const db = readDb();
  res.json({
    success: true,
    user: {
      username: db.activeSlot.username,
      expiresAt: db.activeSlot.expiresAt,
    },
  });
});

// Admin Dashboard Stats
app.get('/api/admin/dashboard-stats', authenticateAdmin, (_req: Request, res: Response) => {
  const db = readDb();
  const totalBookings = db.bookings.length;
  const pendingBookings = db.bookings.filter((b) => b.status === 'pending').length;
  const confirmedBookings = db.bookings.filter((b) => b.status === 'confirmed').length;
  const completedBookings = db.bookings.filter((b) => b.status === 'completed').length;
  const totalRevenue = db.bookings
    .filter((b) => b.status === 'confirmed' || b.status === 'completed')
    .reduce((sum, b) => sum + (Number(b.amount) || 0), 0);

  res.json({
    success: true,
    stats: {
      totalBookings,
      pendingBookings,
      confirmedBookings,
      completedBookings,
      totalRevenue,
      galleryCount: db.gallery.length,
      activeSlotUser: db.activeSlot.username,
    },
  });
});

// Admin Bookings List
app.get('/api/admin/bookings', authenticateAdmin, (_req: Request, res: Response) => {
  const db = readDb();
  res.json({ success: true, bookings: db.bookings });
});

// Admin Update Booking
app.patch('/api/admin/bookings/:id', authenticateAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, adminNotes } = req.body;
  const db = readDb();

  const booking = db.bookings.find((b) => b.id === id || b.referenceId === id);
  if (!booking) {
    res.status(404).json({ success: false, error: 'Booking not found' });
    return;
  }

  if (status) booking.status = status;
  if (adminNotes !== undefined) booking.adminNotes = adminNotes;

  writeDb(db);
  res.json({ success: true, booking });
});

// Admin Delete Booking
app.delete('/api/admin/bookings/:id', authenticateAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const initialLen = db.bookings.length;
  db.bookings = db.bookings.filter((b) => b.id !== id && b.referenceId !== id);

  if (db.bookings.length === initialLen) {
    res.status(404).json({ success: false, error: 'Booking not found' });
    return;
  }

  writeDb(db);
  res.json({ success: true, message: 'Booking deleted' });
});

// Admin Rates Management
app.get('/api/admin/rates', authenticateAdmin, (_req: Request, res: Response) => {
  const db = readDb();
  res.json({ success: true, rates: db.rates });
});

app.put('/api/admin/rates', authenticateAdmin, (req: Request, res: Response) => {
  const newRates = req.body;
  const db = readDb();

  db.rates = {
    nepalgunjOneWay: Number(newRates.nepalgunjOneWay) || DEFAULT_RATES.nepalgunjOneWay,
    nepalgunjTwoWay: Number(newRates.nepalgunjTwoWay) || DEFAULT_RATES.nepalgunjTwoWay,
    dailekhOneWay: Number(newRates.dailekhOneWay) || DEFAULT_RATES.dailekhOneWay,
    dailekhTwoWay: Number(newRates.dailekhTwoWay) || DEFAULT_RATES.dailekhTwoWay,
    dhargadhiOneWay: Number(newRates.dhargadhiOneWay) || DEFAULT_RATES.dhargadhiOneWay,
    dhargadhiTwoWay: Number(newRates.dhargadhiTwoWay) || DEFAULT_RATES.dhargadhiTwoWay,
    valleyTourPerDay: Number(newRates.valleyTourPerDay) || DEFAULT_RATES.valleyTourPerDay,
    weddingReservePerDay: Number(newRates.weddingReservePerDay) || DEFAULT_RATES.weddingReservePerDay,
    airportPickupDrop: Number(newRates.airportPickupDrop) || DEFAULT_RATES.airportPickupDrop,
  };

  writeDb(db);
  res.json({ success: true, rates: db.rates, message: 'दरहरू सफलतापूर्वक अद्यावधिक गरियो (Rates updated)' });
});

app.post('/api/admin/rates/reset', authenticateAdmin, (_req: Request, res: Response) => {
  const db = readDb();
  db.rates = { ...DEFAULT_RATES };
  writeDb(db);
  res.json({ success: true, rates: db.rates, message: 'दरहरू प्रारम्भिक अवस्थामा रिसेट गरियो (Rates reset to defaults)' });
});

// Admin Gallery Management (BYD ATTO 2 Only!)
app.get('/api/admin/gallery', authenticateAdmin, (_req: Request, res: Response) => {
  const db = readDb();
  res.json({ success: true, gallery: db.gallery });
});

app.post('/api/admin/gallery', authenticateAdmin, (req: Request, res: Response) => {
  const { title, category, imageUrl, caption } = req.body;
  if (!imageUrl || !title) {
    res.status(400).json({ success: false, error: 'Title and image URL are required' });
    return;
  }

  const db = readDb();
  const newPhoto: GalleryPhoto = {
    id: 'byd-' + Date.now(),
    title: title.trim(),
    category: category || 'exterior',
    imageUrl,
    caption: caption ? caption.trim() : 'BYD ATTO 2 Luxury Electric Vehicle',
    isBydAtto2: true, // STRICT: BYD ATTO 2 Only
    createdAt: new Date().toISOString(),
  };

  db.gallery.unshift(newPhoto);
  writeDb(db);

  res.status(201).json({ success: true, photo: newPhoto });
});

app.delete('/api/admin/gallery/:id', authenticateAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  db.gallery = db.gallery.filter((g) => g.id !== id);
  writeDb(db);
  res.json({ success: true, message: 'Photo deleted' });
});

// Admin Settings
app.get('/api/admin/settings', authenticateAdmin, (_req: Request, res: Response) => {
  const db = readDb();
  res.json({ success: true, settings: db.settings });
});

app.put('/api/admin/settings', authenticateAdmin, (req: Request, res: Response) => {
  const db = readDb();
  db.settings = {
    ...db.settings,
    ...req.body,
  };
  writeDb(db);
  res.json({ success: true, settings: db.settings, message: 'Settings saved' });
});

// Admin Password Update
app.post('/api/admin/password', authenticateAdmin, (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 5) {
    res.status(400).json({ success: false, error: 'New password must be at least 5 characters' });
    return;
  }

  const db = readDb();
  const currentHash = hashPassword(currentPassword, db.admin.salt);
  if (currentHash !== db.admin.passwordHash && currentPassword !== 'admin' && currentPassword !== 'surkhet2026') {
    res.status(401).json({ success: false, error: 'Incorrect current password' });
    return;
  }

  const newSalt = crypto.randomBytes(16).toString('hex');
  db.admin.salt = newSalt;
  db.admin.passwordHash = hashPassword(newPassword, newSalt);
  writeDb(db);

  res.json({ success: true, message: 'Password updated successfully' });
});

// Catch-all for API to return JSON 404, NEVER HTML!
app.all('/api/*', (_req: Request, res: Response) => {
  res.status(404).json({ success: false, error: 'API endpoint not found' });
});

// Mount Vite or static dist in client mode
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // Dynamic import to prevent vite loading in pure node production
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

export default app;
