import { RoutePlan, ServiceRates } from '../types/index.ts';

export const DEFAULT_RATES: ServiceRates = {
  nepalgunjOneWay: 5000,
  nepalgunjTwoWay: 8000,
  dailekhOneWay: 6000,
  dailekhTwoWay: 8000,
  dhargadhiOneWay: 15000,
  dhargadhiTwoWay: 18000,
  valleyTourPerDay: 5000,
  weddingReservePerDay: 5000,
  airportPickupDrop: 1000,
};

export interface PricingResult {
  amount: number | null;
  formattedAmount: string;
  serviceTitleNepali: string;
  serviceTitleEnglish: string;
  tripType: string;
  planDescription: string;
  daysDescription?: string;
  isValid: boolean;
  message?: string;
}

/**
 * Single Source of Truth for calculating prices across:
 * - Public booking form
 * - Real-time selection summary
 * - Booking confirmation modal
 * - Client submission
 * - Server backend verification
 * - Admin panel views
 */
export function calculatePrice(
  serviceId: string,
  options?: {
    plan?: RoutePlan;
    days?: number;
    rates?: Partial<ServiceRates>;
  }
): PricingResult {
  const currentRates: ServiceRates = {
    ...DEFAULT_RATES,
    ...(options?.rates || {}),
  };

  const plan = options?.plan || 'one-way';
  const days = Math.max(1, Math.floor(options?.days || 1));

  if (!serviceId) {
    return {
      amount: null,
      formattedAmount: 'कृपया सेवा चयन गर्नुहोस्',
      serviceTitleNepali: 'कृपया सेवा चयन गर्नुहोस्',
      serviceTitleEnglish: 'Please select a service',
      tripType: 'अनिर्धारित (Not Selected)',
      planDescription: 'लागु हुँदैन',
      isValid: false,
      message: 'कृपया सेवा चयन गर्नुहोस् (Please select a service)',
    };
  }

  switch (serviceId) {
    case 'surkhet-nepalgunj': {
      const isTwoWay = plan === 'two-way';
      const amount = isTwoWay ? currentRates.nepalgunjTwoWay : currentRates.nepalgunjOneWay;
      return {
        amount,
        formattedAmount: `रु. ${amount.toLocaleString('en-IN')}`,
        serviceTitleNepali: 'सुर्खेत → नेपालगन्ज',
        serviceTitleEnglish: 'Surkhet to Nepalgunj',
        tripType: isTwoWay ? 'Two Way (दोहोरो यात्रा)' : 'One Way (एकतर्फी यात्रा)',
        planDescription: isTwoWay ? 'Two Way' : 'One Way',
        isValid: true,
      };
    }

    case 'surkhet-dailekh': {
      const isTwoWay = plan === 'two-way';
      const amount = isTwoWay ? currentRates.dailekhTwoWay : currentRates.dailekhOneWay;
      return {
        amount,
        formattedAmount: `रु. ${amount.toLocaleString('en-IN')}`,
        serviceTitleNepali: 'सुर्खेत → दैलेख',
        serviceTitleEnglish: 'Surkhet to Dailekh',
        tripType: isTwoWay ? 'Two Way (दोहोरो यात्रा)' : 'One Way (एकतर्फी यात्रा)',
        planDescription: isTwoWay ? 'Two Way' : 'One Way',
        isValid: true,
      };
    }

    case 'surkhet-dhargadhi': {
      const isTwoWay = plan === 'two-way';
      const amount = isTwoWay ? currentRates.dhargadhiTwoWay : currentRates.dhargadhiOneWay;
      return {
        amount,
        formattedAmount: `रु. ${amount.toLocaleString('en-IN')}`,
        serviceTitleNepali: 'सुर्खेत → धनगढी (Dhargadhi)',
        serviceTitleEnglish: 'Surkhet to Dhargadhi',
        tripType: isTwoWay ? 'Two Way (दोहोरो यात्रा)' : 'One Way (एकतर्फी यात्रा)',
        planDescription: isTwoWay ? 'Two Way' : 'One Way',
        isValid: true,
      };
    }

    case 'valley-tour': {
      const amount = currentRates.valleyTourPerDay * days;
      return {
        amount,
        formattedAmount: `रु. ${amount.toLocaleString('en-IN')}`,
        serviceTitleNepali: 'सुर्खेत उपत्यका भ्रमण (Valley Tour)',
        serviceTitleEnglish: 'Surkhet Valley Tour',
        tripType: `दैनिक भ्रमण (${days} दिन)`,
        planDescription: `रु. ${currentRates.valleyTourPerDay.toLocaleString('en-IN')} प्रति दिन`,
        daysDescription: `${days} दिन (${days} ${days > 1 ? 'Days' : 'Day'})`,
        isValid: true,
      };
    }

    case 'wedding-reserve': {
      const amount = currentRates.weddingReservePerDay * days;
      return {
        amount,
        formattedAmount: `रु. ${amount.toLocaleString('en-IN')}`,
        serviceTitleNepali: 'वैवाहिक लक्जरी कार रिजर्भ (Wedding Reserve)',
        serviceTitleEnglish: 'Wedding Reserve Service',
        tripType: `विवाह विशेष रिजर्भ (${days} दिन)`,
        planDescription: `रु. ${currentRates.weddingReservePerDay.toLocaleString('en-IN')} प्रति दिन`,
        daysDescription: `${days} दिन (${days} ${days > 1 ? 'Days' : 'Day'})`,
        isValid: true,
      };
    }

    case 'airport-pickup-drop': {
      const amount = currentRates.airportPickupDrop; // Exactly 1,000! Never 5,000
      return {
        amount,
        formattedAmount: `रु. ${amount.toLocaleString('en-IN')}`,
        serviceTitleNepali: 'सुर्खेत विमानस्थल पिकअप र ड्रप',
        serviceTitleEnglish: 'Surkhet Airport Pickup & Drop',
        tripType: 'Pickup & Drop',
        planDescription: 'विमानस्थल स्थानान्तरण (Airport Transfer)',
        isValid: true,
      };
    }

    default:
      return {
        amount: null,
        formattedAmount: 'कृपया सेवा चयन गर्नुहोस्',
        serviceTitleNepali: 'अज्ञात सेवा',
        serviceTitleEnglish: 'Unknown Service',
        tripType: 'अनिर्धारित',
        planDescription: 'अमान्य',
        isValid: false,
        message: 'कृपया सेवा चयन गर्नुहोस्',
      };
  }
}
