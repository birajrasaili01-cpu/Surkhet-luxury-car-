import heroImg from '../assets/images/byd_atto_2_hero_1790175652304.jpg';
import frontImg from '../assets/images/byd_atto_2_front_1790175668365.jpg';
import interiorImg from '../assets/images/byd_atto_2_interior_1790175686582.jpg';
import rearImg from '../assets/images/byd_atto_2_rear_1790175706520.jpg';
import { GalleryPhoto } from '../types/index.ts';

export const BYD_ATTO_2_IMAGES = {
  hero: heroImg,
  front: frontImg,
  interior: interiorImg,
  rear: rearImg,
  placeholderText: 'BYD ATTO 2 Image',
  modelName: 'BYD ATTO 2',
  subtitle: '100% Pure Electric Luxury SUV',
};

export const INITIAL_BYD_GALLERY: GalleryPhoto[] = [
  {
    id: 'byd-1',
    title: 'BYD ATTO 2 - Scenic Surkhet Valley',
    category: 'exterior',
    imageUrl: heroImg,
    caption: 'BYD ATTO 2 Luxury Electric SUV in scenic Surkhet valley hills at sunset',
    isBydAtto2: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'byd-2',
    title: 'BYD ATTO 2 - Front Aerodynamic Fascia',
    category: 'exterior',
    imageUrl: frontImg,
    caption: 'Sleek crystal LED headlights, signature sealed EV grille, and sculpted front profile',
    isBydAtto2: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'byd-3',
    title: 'BYD ATTO 2 - Executive Cockpit & Touchscreen',
    category: 'interior',
    imageUrl: interiorImg,
    caption: 'Rotatable intelligent touchscreen, luxury ergonomic vegan leather seats, and ambient lighting',
    isBydAtto2: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'byd-4',
    title: 'BYD ATTO 2 - Continuous LED Taillight Bar',
    category: 'exterior',
    imageUrl: rearImg,
    caption: 'Aerodynamic rear spoiler, continuous dynamic LED taillight bar, and high ground clearance',
    isBydAtto2: true,
    createdAt: new Date().toISOString(),
  },
];
