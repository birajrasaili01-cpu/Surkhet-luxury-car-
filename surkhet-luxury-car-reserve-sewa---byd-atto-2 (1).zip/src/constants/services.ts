import { ServiceDefinition } from '../types/index.ts';
import { BYD_ATTO_2_IMAGES } from './images.ts';

export const ALL_SERVICES: ServiceDefinition[] = [
  {
    id: 'surkhet-nepalgunj',
    titleNepali: 'सुर्खेत → नेपालगन्ज',
    titleEnglish: 'Surkhet to Nepalgunj',
    type: 'route',
    description: 'रत्न राजमार्ग हुँदै नेपालगन्जको लागि सुरक्षित, आरामदायी तथा आधुनिक BYD ATTO 2 विद्युतीय कार रिजर्भ।',
    basePriceText: 'One Way: रु. 5,000 | Two Way: रु. 8,000',
    features: [
      'निजी वातानुकूलित (AC) क्याबिन',
      'One Way (रु. 5,000) वा Two Way (रु. 8,000)',
      'व्यावसायिक तथा अनुभवी चालक',
      'मोबाइल चार्जिङ तथा वाइफाइ',
    ],
  },
  {
    id: 'surkhet-dailekh',
    titleNepali: 'सुर्खेत → दैलेख',
    titleEnglish: 'Surkhet to Dailekh',
    type: 'route',
    description: 'ऐतिहासिक दैलेख बजार, पञ्चकोशी क्षेत्र तथा सरकारी कामका लागि उच्च ग्राउन्ड क्लियरेन्स भएको BYD ATTO 2 यात्रा।',
    basePriceText: 'One Way: रु. 6,000 | Two Way: रु. 8,000',
    features: [
      'पहाडी सडकमा सुरक्षित तथा आरामदायी यात्रा',
      'One Way (रु. 6,000) वा Two Way (रु. 8,000)',
      'कुनै पनि समय पिकअप र ड्रप',
      'पारिवारिक तथा अफिसियल यात्रा',
    ],
  },
  {
    id: 'surkhet-dhargadhi',
    titleNepali: 'सुर्खेत → धनगढी (Dhargadhi)',
    titleEnglish: 'Surkhet to Dhargadhi',
    type: 'route',
    description: 'सुदूरपश्चिम प्रदेशको प्रमुख सहर धनगढीका लागि द्रुत, लक्जरी र पूर्ण विद्युतीय प्रिमियम कार रिजर्भ।',
    basePriceText: 'One Way: रु. 15,000 | Two Way: रु. 18,000',
    features: [
      'लामो दूरीको लागि परम आरामदायी सिट',
      'One Way (रु. 15,000) वा Two Way (रु. 18,000)',
      'अत्याधुनिक सुरक्षा (६ वटा एयरब्याग्स)',
      'लगेजको लागि प्रशस्त ठाउँ',
    ],
  },
  {
    id: 'valley-tour',
    titleNepali: 'सुर्खेत उपत्यका भ्रमण (Valley Tour)',
    titleEnglish: 'Surkhet Valley Tour',
    type: 'per-day',
    description: 'काँक्रेविहार, बुलबुले ताल, देउती बज्यै, घण्टाघर लगायत सुर्खेत उपत्यकाका दर्शनीय स्थलहरूको दिनभरि आनन्द लिनुहोस्।',
    basePriceText: 'रु. 5,000 प्रति दिन (Per Day)',
    features: [
      'दैनिक आधारमा भाडा (प्रति दिन रु. ५,०००)',
      'इच्छित पर्यटकीय स्थलहरू घुम्न सकिने',
      'शान्त, ध्वनि-रहित विद्युतीय EV अनुभव',
      'पारिवारिक वा समूह भ्रमणका लागि उत्तम',
    ],
  },
  {
    id: 'wedding-reserve',
    titleNepali: 'वैवाहिक लक्जरी कार रिजर्भ',
    titleEnglish: 'Wedding Reserve Service',
    type: 'per-day',
    description: 'तपाईंको जीवनको विशेष दिनलाई अझ विशेष बनाउन फूलले सजिएको प्रिमियम BYD ATTO 2 विवाह कार सेवा।',
    basePriceText: 'रु. 5,000 प्रति दिन (Per Day)',
    features: [
      'प्रति दिन रु. ५,००० मा विशेष विवाह रिजर्भ',
      'दम्पतीका लागि लक्जरी इन्टेरियर र सत्कार',
      'समयनिष्ठ र सुसज्जित चालक सेवा',
      'सम्पूर्ण सुर्खेत तथा आसपासका जिल्लामा उपलब्ध',
    ],
  },
  {
    id: 'airport-pickup-drop',
    titleNepali: 'सुर्खेत विमानस्थल पिकअप र ड्रप',
    titleEnglish: 'Surkhet Airport Pickup & Drop',
    type: 'airport',
    description: 'सुर्खेत विमानस्थल (SKH) बाट तपाईंको होटेल वा घरसम्म र घरबाट विमानस्थलसम्म समयमै सहज पिकअप र ड्रप सेवा।',
    basePriceText: 'कुल रकम: रु. 1,000 (Fixed)',
    features: [
      'निश्चित सस्तो भाडा: मात्र रु. १,००० (रु. ५,००० होइन)',
      'विमान अवतरण समय अनुसार ढिलाइ बिना पिकअप',
      'सहज लगेज ह्यान्डलिङ',
      '२४ सै घण्टा पूर्व-बुकिङ उपलब्ध',
    ],
  },
];
