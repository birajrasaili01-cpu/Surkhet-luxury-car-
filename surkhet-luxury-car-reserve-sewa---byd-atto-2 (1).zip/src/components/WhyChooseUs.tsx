import React from 'react';
import { UserCheck, Wind, Clock, BadgePercent, PhoneCall, MapPin, ArrowRight } from 'lucide-react';

interface WhyChooseUsProps {
  onBookNow: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onBookNow }) => {
  const cards = [
    {
      icon: <UserCheck className="w-6 h-6 text-amber-600" />,
      text: 'अनुभवी, व्यावसायिक र शलीन चालक।',
      label: 'दक्ष चालकदल (Professional Chauffeurs)',
    },
    {
      icon: <Wind className="w-6 h-6 text-amber-600" />,
      text: 'पूर्ण रूपमा एयर-कन्डिसन्ड (A/C) र आरामदायी सिट।',
      label: 'लक्जरी क्याबिन (A/C & Luxury Comfort)',
    },
    {
      icon: <Clock className="w-6 h-6 text-amber-600" />,
      text: '२४ सै घण्टा अन-कल तथा अनलाइन बुकिङ सुविधा।',
      label: '२४/७ सेवा (24/7 On-Call Booking)',
    },
    {
      icon: <BadgePercent className="w-6 h-6 text-amber-600" />,
      text: 'सुलभ तथा पारदर्शी भाडा दर।',
      label: 'पारदर्शी हिसाब (Transparent Fair Pricing)',
    },
  ];

  return (
    <section id="why-choose-us" className="py-16 sm:py-20 bg-gray-50 border-y border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider mb-3">
            हाम्रो विशेषता
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight font-['Outfit']">
            हामीलाई नै किन रोज्ने?
          </h2>
          <p className="mt-3 text-gray-600 text-base sm:text-lg">
            सुर्खेत तथा कर्णाली प्रदेशमा भरपर्दो, सुरक्षित र प्रिमियम विद्युतीय BYD ATTO 2 यात्रा अनुभव।
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {cards.map((card, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 sm:p-7 border border-gray-200 shadow-sm hover:shadow-md hover:border-amber-400 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center mb-5">
                  {card.icon}
                </div>
                <div className="text-[11px] font-semibold text-amber-700 uppercase tracking-wider mb-2">
                  {card.label}
                </div>
                <h3 className="text-lg font-bold text-gray-900 leading-snug">
                  {card.text}
                </h3>
              </div>
              <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500 font-medium">
                <span>BYD ATTO 2</span>
                <span className="text-emerald-700 font-bold">ग्यारेन्टी</span>
              </div>
            </div>
          ))}
        </div>

        {/* Final CTA Banner */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <h3 className="text-xl sm:text-2xl font-extrabold text-gray-900 font-['Outfit']">
              अहिले नै सम्पर्क गरी आफ्नो यात्रा सुरक्षित गर्नुहोस्!
            </h3>
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 pt-1">
              <div className="flex items-center gap-2 font-bold text-gray-900">
                <div className="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                  <PhoneCall className="w-4 h-4" />
                </div>
                <a href="tel:9802581402" className="text-amber-700 hover:text-amber-800 text-lg font-black tracking-wide font-['Outfit']">
                  9802581402
                </a>
              </div>
              <span className="text-gray-300 hidden sm:inline">•</span>
              <div className="flex items-center gap-1.5 font-medium text-gray-700">
                <MapPin className="w-4 h-4 text-gray-500" />
                <span>वीरेन्द्रनगर, सुर्खेत</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="tel:9802581402"
              className="px-6 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-sm shadow-md hover:shadow-lg transition-all flex items-center gap-2.5 active:scale-95 border border-amber-400/40"
              title="सिधा कल: 9802581402"
            >
              <PhoneCall className="w-4 h-4 fill-current" />
              <span>सिधा कल: <strong className="font-['Outfit'] tracking-wider">9802581402</strong></span>
            </a>
            <button
              onClick={onBookNow}
              className="px-6 py-3.5 rounded-xl bg-gray-900 hover:bg-gray-800 text-white font-bold text-sm shadow-sm transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>कार रिजर्भ गर्नुहोस्</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
