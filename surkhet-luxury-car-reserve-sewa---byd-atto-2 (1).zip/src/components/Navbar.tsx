import React, { useState } from 'react';
import { Phone, Menu, X, Car, Calendar } from 'lucide-react';
import { BusinessSettings } from '../types/index.ts';

interface NavbarProps {
  settings?: BusinessSettings;
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ settings, onOpenBooking }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const phone = settings?.phone || '9802581402';

  const navLinks = [
    { name: 'गृहपृष्ठ (Home)', href: '#hero' },
    { name: 'हाम्रो कार (Our Car)', href: '#our-car' },
    { name: 'किन रोज्ने? (Why Us)', href: '#why-choose-us' },
    { name: 'सेवाहरू (Services)', href: '#services' },
    { name: 'दररेट (Pricing)', href: '#pricing' },
    { name: 'ग्यालरी (Gallery)', href: '#gallery' },
    { name: 'सम्पर्क (Contact)', href: '#contact' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-xs">
      {/* Top micro bar for phone & location */}
      <div className="bg-gray-50 border-b border-gray-100 text-xs py-1.5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-gray-600">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-gray-800">
              वीरेन्द्रनगर, सुर्खेत
            </span>
            <span className="hidden sm:inline text-gray-300">|</span>
            <span className="hidden sm:inline text-gray-600 font-medium">
              १००% विद्युतीय BYD ATTO 2 लक्जरी सेवा
            </span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href={`tel:${phone.replace(/[^0-9]/g, '')}`}
              className="flex items-center gap-1.5 font-bold text-amber-700 hover:text-amber-800"
            >
              <Phone className="w-3.5 h-3.5 text-amber-600" />
              <span>सम्पर्क: {phone}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Brand Logo & Name */}
          <a href="#hero" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shadow-xs group-hover:border-amber-400 transition-colors">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <span className="text-base sm:text-lg font-black text-gray-900 tracking-tight block font-['Outfit'] leading-none">
                SURKHET LUXURY CAR
              </span>
              <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider block mt-0.5">
                RESERVE SEWA • BYD ATTO 2
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-3 py-1.5 text-xs xl:text-sm font-semibold text-gray-700 hover:text-amber-600 hover:bg-gray-50 rounded-lg transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Desktop CTAs */}
          <div className="hidden md:flex items-center gap-2.5">
            <a
              href={`tel:${phone.replace(/[^0-9]/g, '')}`}
              className="px-3.5 py-2 rounded-xl border border-amber-200 bg-amber-50/80 hover:bg-amber-100/80 text-gray-900 text-xs font-extrabold transition-all flex items-center gap-2 shadow-2xs group active:scale-95"
              title={`सिधा सम्पर्क: ${phone}`}
            >
              <div className="w-6 h-6 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <Phone className="w-3.5 h-3.5 fill-current" />
              </div>
              <div className="flex flex-col text-left leading-none">
                <span className="text-[9px] uppercase font-bold text-amber-800 tracking-wider">कल गर्नुहोस्</span>
                <span className="text-xs font-black text-gray-900 font-['Outfit'] mt-0.5">{phone}</span>
              </div>
            </a>

            <button
              onClick={onOpenBooking}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs sm:text-sm font-extrabold shadow-xs transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Calendar className="w-4 h-4 text-white" />
              <span>कार रिजर्भ गर्नुहोस्</span>
            </button>
          </div>

          {/* Mobile Hamburger Button & Clear Call Button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={`tel:${phone.replace(/[^0-9]/g, '')}`}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-black text-xs shadow-xs"
              title={`Call ${phone}`}
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              <span className="font-['Outfit']">{phone}</span>
            </a>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-gray-100 text-gray-700 hover:text-gray-900 hover:bg-gray-200 cursor-pointer"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 px-4 pt-3 pb-6 space-y-3 animate-in fade-in duration-150">
          <nav className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-semibold text-gray-800 hover:text-amber-600 hover:bg-gray-50 rounded-lg transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          <div className="pt-3 border-t border-gray-100 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm shadow-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>कार रिजर्भ गर्नुहोस्</span>
            </button>

            <a
              href={`tel:${phone.replace(/[^0-9]/g, '')}`}
              className="w-full py-2.5 rounded-xl border border-gray-200 text-gray-800 font-bold text-sm text-center flex items-center justify-center gap-2 bg-gray-50"
            >
              <Phone className="w-4 h-4 text-amber-600" />
              <span>कल गर्नुहोस्: {phone}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
