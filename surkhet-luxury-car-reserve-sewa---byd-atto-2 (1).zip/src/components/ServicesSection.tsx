import React from 'react';
import { ALL_SERVICES } from '../constants/services.ts';
import { ServiceRates } from '../types/index.ts';
import { ArrowRight, Plane, MapPin, Calendar, Heart, Check } from 'lucide-react';

interface ServicesSectionProps {
  rates: ServiceRates;
  onSelectService: (serviceId: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ rates, onSelectService }) => {
  const getRateDisplay = (serviceId: string) => {
    switch (serviceId) {
      case 'surkhet-nepalgunj':
        return {
          highlight: `One Way: रु. ${rates.nepalgunjOneWay.toLocaleString('en-IN')}`,
          sub: `Two Way: रु. ${rates.nepalgunjTwoWay.toLocaleString('en-IN')}`,
        };
      case 'surkhet-dailekh':
        return {
          highlight: `One Way: रु. ${rates.dailekhOneWay.toLocaleString('en-IN')}`,
          sub: `Two Way: रु. ${rates.dailekhTwoWay.toLocaleString('en-IN')}`,
        };
      case 'surkhet-dhargadhi':
        return {
          highlight: `One Way: रु. ${rates.dhargadhiOneWay.toLocaleString('en-IN')}`,
          sub: `Two Way: रु. ${rates.dhargadhiTwoWay.toLocaleString('en-IN')}`,
        };
      case 'valley-tour':
        return {
          highlight: `रु. ${rates.valleyTourPerDay.toLocaleString('en-IN')} / दिन`,
          sub: 'दैनिक भ्रमण (Per Day Rate)',
        };
      case 'wedding-reserve':
        return {
          highlight: `रु. ${rates.weddingReservePerDay.toLocaleString('en-IN')} / दिन`,
          sub: 'विवाह विशेष सेवा (Per Day)',
        };
      case 'airport-pickup-drop':
        return {
          highlight: `रु. ${rates.airportPickupDrop.toLocaleString('en-IN')} (फिक्स)`,
          sub: 'सुर्खेत विमानस्थल (Airport Transfer)',
        };
      default:
        return { highlight: 'दर उपलब्ध छ', sub: '' };
    }
  };

  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'airport-pickup-drop':
        return <Plane className="w-5 h-5 text-amber-600" />;
      case 'wedding-reserve':
        return <Heart className="w-5 h-5 text-rose-500" />;
      case 'valley-tour':
        return <MapPin className="w-5 h-5 text-emerald-600" />;
      default:
        return <ArrowRight className="w-5 h-5 text-amber-600" />;
    }
  };

  return (
    <section id="services" className="py-16 sm:py-22 bg-gray-50/70 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider mb-3">
            हाम्रा प्रमुख सेवाहरू
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 tracking-tight font-['Outfit']">
            लक्जरी रुट तथा <span className="text-amber-600">रिजर्भ सेवाहरू</span>
          </h2>
          <p className="mt-3 text-gray-600 text-base sm:text-lg">
            पारदर्शी भाडा दर, कुनै लुकेको शुल्क नभएको १००% शुद्ध विद्युतीय BYD ATTO 2 यात्रा अनुभव।
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {ALL_SERVICES.map((service) => {
            const pricing = getRateDisplay(service.id);
            const isAirport = service.id === 'airport-pickup-drop';

            return (
              <div
                key={service.id}
                className={`flex flex-col justify-between rounded-2xl p-6 sm:p-7 transition-all duration-200 bg-white border ${
                  isAirport
                    ? 'border-amber-400 shadow-md ring-1 ring-amber-400/20'
                    : 'border-gray-200 shadow-xs hover:border-amber-400 hover:shadow-md'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-11 h-11 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center">
                      {getServiceIcon(service.id)}
                    </div>
                    {isAirport ? (
                      <span className="text-[11px] px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 font-bold border border-amber-300 uppercase">
                        फिक्स रु. १,००० मात्र
                      </span>
                    ) : (
                      <span className="text-[11px] px-2.5 py-0.5 rounded-md bg-gray-100 text-gray-700 font-semibold border border-gray-200">
                        BYD ATTO 2
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg sm:text-xl font-bold text-gray-900 font-['Outfit'] leading-tight mb-1">
                    {service.titleNepali}
                  </h3>
                  <p className="text-xs text-gray-500 mb-4">{service.titleEnglish}</p>

                  <p className="text-xs sm:text-sm text-gray-600 mb-5 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Features list */}
                  <ul className="space-y-2 mb-6">
                    {service.features.map((f, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-xs text-gray-700">
                        <Check className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Price and CTA */}
                <div className="pt-4 border-t border-gray-100 mt-auto">
                  <div className="flex items-baseline justify-between mb-4">
                    <div>
                      <div className="text-lg sm:text-xl font-black text-amber-700 font-['Outfit']">
                        {pricing.highlight}
                      </div>
                      <div className="text-xs text-gray-500">{pricing.sub}</div>
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectService(service.id)}
                    className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-sm tracking-wide shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                  >
                    <span>यो सेवा रोज्नुहोस् (Select)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
