import React, { useState } from 'react';
import { ShieldCheck, Zap } from 'lucide-react';
import { BYD_ATTO_2_IMAGES } from '../constants/images.ts';

interface BydImageProps {
  src?: string;
  alt?: string;
  className?: string;
  showBadge?: boolean;
  priority?: boolean;
}

export const BydImage: React.FC<BydImageProps> = ({
  src,
  alt = 'BYD ATTO 2 Luxury Electric SUV',
  className = '',
  showBadge = true,
}) => {
  const [hasError, setHasError] = useState(false);
  const imageSource = src && !hasError ? src : BYD_ATTO_2_IMAGES.hero;

  return (
    <div className={`relative overflow-hidden group ${className}`}>
      {hasError ? (
        <div className="w-full h-full min-h-[220px] flex flex-col items-center justify-center bg-gradient-to-br from-[#121629] to-[#1f1b3c] border border-amber-500/30 text-center p-6 rounded-xl">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-3 text-amber-400">
            <Zap className="w-7 h-7" />
          </div>
          <span className="text-xl font-bold tracking-wider text-amber-300 font-['Outfit']">
            BYD ATTO 2 Image
          </span>
          <span className="text-xs text-slate-400 mt-1">
            Surkhet Luxury Car Reserve Sewa • 100% Electric EV
          </span>
        </div>
      ) : (
        <>
          <img
            src={imageSource}
            alt={alt.includes('BYD ATTO 2') ? alt : `BYD ATTO 2 - ${alt}`}
            onError={() => setHasError(true)}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          {showBadge && (
            <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md border border-amber-500/40 text-[11px] font-semibold text-amber-300 shadow-lg">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>BYD ATTO 2</span>
            </div>
          )}
        </>
      )}
    </div>
  );
};
