import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  User,
  Phone,
  Mail,
  Users,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Car,
  X,
  FileText,
  Plane,
} from 'lucide-react';
import { ALL_SERVICES } from '../constants/services.ts';
import { RoutePlan, ServiceRates, BookingItem } from '../types/index.ts';
import { calculatePrice } from '../utils/pricing.ts';
import { api } from '../services/api.ts';
import { saveBookingToSupabase } from '../services/supabase.ts';

interface BookingFormProps {
  rates: ServiceRates;
  initialServiceId?: string;
  initialPlan?: RoutePlan;
  onBookingSuccess?: (booking: BookingItem) => void;
}

export const BookingForm: React.FC<BookingFormProps> = ({
  rates,
  initialServiceId = '',
  initialPlan = 'one-way',
  onBookingSuccess,
}) => {
  // Selection States
  const [serviceId, setServiceId] = useState<string>(initialServiceId);
  const [routePlan, setRoutePlan] = useState<RoutePlan>(initialPlan);
  const [numberOfDays, setNumberOfDays] = useState<number>(1);

  // Dynamic context fields based on service type
  const [airportTripType, setAirportTripType] = useState<'pickup' | 'drop'>('pickup');
  const [flightInfo, setFlightInfo] = useState('');
  const [surkhetAddressNote, setSurkhetAddressNote] = useState('');
  const [venueOrHotel, setVenueOrHotel] = useState('');

  // Customer Form States
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [pickupDate, setPickupDate] = useState('');
  const [pickupTime, setPickupTime] = useState('');
  const [passengerCount, setPassengerCount] = useState(1);
  const [specialRequests, setSpecialRequests] = useState('');

  // Status & modal states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [confirmedBooking, setConfirmedBooking] = useState<BookingItem | null>(null);

  // Sync initial props if changed from outside
  useEffect(() => {
    if (initialServiceId) {
      setServiceId(initialServiceId);
      if (initialPlan) setRoutePlan(initialPlan);
    }
  }, [initialServiceId, initialPlan]);

  const selectedService = ALL_SERVICES.find((s) => s.id === serviceId);

  // Centralized price calculation (Single Source of Truth)
  const pricing = calculatePrice(serviceId, {
    plan: routePlan,
    days: numberOfDays,
    rates,
  });

  const handleServiceChange = (newServiceId: string) => {
    setServiceId(newServiceId);
    setErrorMessage(null);
    const service = ALL_SERVICES.find((s) => s.id === newServiceId);
    if (service?.type === 'route') {
      setRoutePlan('one-way');
    } else if (service?.type === 'per-day') {
      setNumberOfDays(1);
    }
  };

  // Helper to determine automatic locations
  const getAutoLocations = () => {
    if (!selectedService) {
      return { pickup: '', drop: '' };
    }

    if (selectedService.id === 'surkhet-nepalgunj') {
      return {
        pickup: 'सुर्खेत (Surkhet)',
        drop: 'नेपालगन्ज (Nepalgunj)',
      };
    }
    if (selectedService.id === 'surkhet-dailekh') {
      return {
        pickup: 'सुर्खेत (Surkhet)',
        drop: 'दैलेख (Dailekh)',
      };
    }
    if (selectedService.id === 'surkhet-dhargadhi') {
      return {
        pickup: 'सुर्खेत (Surkhet)',
        drop: 'धनगढी (Dhargadhi)',
      };
    }
    if (selectedService.id === 'airport-pickup-drop') {
      if (airportTripType === 'pickup') {
        return {
          pickup: 'सुर्खेत विमानस्थल (Surkhet Airport - SKH)',
          drop: venueOrHotel ? `${venueOrHotel}, सुर्खेत` : 'होटेल / घर (सुर्खेत)',
        };
      } else {
        return {
          pickup: venueOrHotel ? `${venueOrHotel}, सुर्खेत` : 'होटेल / घर (सुर्खेत)',
          drop: 'सुर्खेत विमानस्थल (Surkhet Airport - SKH)',
        };
      }
    }
    if (selectedService.id === 'valley-tour') {
      return {
        pickup: venueOrHotel ? `${venueOrHotel}, सुर्खेत` : 'वीरेन्द्रनगर, सुर्खेत',
        drop: 'सुर्खेत उपत्यका दर्शनीय स्थलहरू (Valley Tour Points)',
      };
    }
    if (selectedService.id === 'wedding-reserve') {
      return {
        pickup: venueOrHotel ? `${venueOrHotel}` : 'तोकिएको निवास (सुर्खेत)',
        drop: 'विवाह मण्डप / पार्टी प्यालेस',
      };
    }

    return { pickup: 'सुर्खेत', drop: 'गन्तव्य' };
  };

  const autoLocs = getAutoLocations();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!serviceId) {
      setErrorMessage('कृपया पहिले सेवा चयन गर्नुहोस् (Please select a service first)');
      return;
    }

    if (!customerName.trim()) {
      setErrorMessage('कृपया तपाईंको नाम लेख्नुहोस् (Full Name is required)');
      return;
    }

    if (!customerPhone.trim() || customerPhone.trim().length < 8) {
      setErrorMessage('कृपया मान्य फोन नम्बर लेख्नुहोस् (Valid Phone Number is required)');
      return;
    }

    if (!pickupDate) {
      setErrorMessage('कृपया यात्रा मिति छान्नुहोस् (Pickup Date is required)');
      return;
    }

    if (!pricing.isValid || pricing.amount === null) {
      setErrorMessage('अमान्य भाडा हिसाब (Invalid pricing calculation)');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload: Partial<BookingItem> = {
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerEmail: customerEmail.trim() || undefined,
        serviceId,
        serviceName: pricing.serviceTitleNepali,
        tripType: pricing.tripType,
        routePlan: selectedService?.type === 'route' ? routePlan : undefined,
        numberOfDays: selectedService?.type === 'per-day' ? numberOfDays : undefined,
        pickupDate,
        pickupTime: pickupTime || 'As per booking',
        pickupLocation: autoLocs.pickup,
        dropLocation: autoLocs.drop,
        passengerCount,
        specialRequests: [
          flightInfo ? `उडान/विमान: ${flightInfo}` : null,
          surkhetAddressNote ? `विशिष्ट ठेगाना: ${surkhetAddressNote}` : null,
          specialRequests.trim() || null,
        ]
          .filter(Boolean)
          .join(' | ') || undefined,
        amount: pricing.amount,
      };

      const result = await api.submitBooking(payload);

      if (result.success && result.booking) {
        setConfirmedBooking(result.booking);
        // Direct client-side dual-sync to Supabase backend
        saveBookingToSupabase(result.booking).catch((err) => {
          console.warn('[Supabase client sync note]', err);
        });
        if (onBookingSuccess) {
          onBookingSuccess(result.booking);
        }
      } else {
        setErrorMessage(result.error || 'बुकिङ पेश गर्दा समस्या आयो। कृपया पुनः प्रयास गर्नुहोस्।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'त्रुटि देखा पर्यो। कृपया पुनः प्रयास गर्नुहोस्।');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setConfirmedBooking(null);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerEmail('');
    setPickupDate('');
    setPickupTime('');
    setSurkhetAddressNote('');
    setVenueOrHotel('');
    setFlightInfo('');
    setPassengerCount(1);
    setSpecialRequests('');
    setServiceId('');
  };

  return (
    <div id="booking-section" className="relative">
      {/* Booking Form Card */}
      <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-10 shadow-sm relative">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-gray-200 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200 uppercase tracking-wide mb-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              अनलाइन कार रिजर्भ फारम
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-gray-900 font-['Outfit']">
              Reserve Your <span className="text-amber-600">BYD ATTO 2</span>
            </h3>
            <p className="text-xs sm:text-sm text-gray-500 mt-1">
              SURKHET LUXURY CAR RESERVE SEWA • पारदर्शी हिसाब र तत्काल पुष्टि
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <a
              href="tel:9802581402"
              className="px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-gray-900 flex items-center gap-2.5 transition-all shadow-2xs group active:scale-95"
              title="सिधा फोन सम्पर्क: 9802581402"
            >
              <div className="w-7 h-7 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <Phone className="w-3.5 h-3.5 fill-current" />
              </div>
              <div className="text-left leading-none">
                <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider block">सिधा कल बुकिङ</span>
                <span className="text-xs sm:text-sm font-black text-gray-900 font-['Outfit'] mt-0.5 block">9802581402</span>
              </div>
            </a>

            <div className="hidden sm:flex px-3.5 py-2.5 rounded-xl bg-gray-50 border border-gray-200 items-center gap-2.5">
              <Car className="w-4 h-4 text-amber-600" />
              <div className="text-left leading-tight">
                <div className="text-xs font-bold text-gray-900">BYD ATTO 2</div>
                <div className="text-[10px] text-emerald-700 font-semibold">१००% विद्युतीय EV</div>
              </div>
            </div>
          </div>
        </div>

        {/* Error banner */}
        {errorMessage && (
          <div className="my-6 p-4 rounded-xl bg-red-50 border border-red-200 flex items-start gap-3 text-red-800 text-sm">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1 font-medium">{errorMessage}</div>
            <button onClick={() => setErrorMessage(null)} className="text-red-500 hover:text-red-800">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-8 space-y-8">
          {/* STEP 1: SERVICE SELECTION */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-amber-500 text-white font-extrabold flex items-center justify-center text-xs">
                १
              </div>
              <label htmlFor="service-select" className="text-base font-bold text-gray-900 font-['Outfit']">
                सेवा छान्नुहोस् (Select Service) <span className="text-amber-600">*</span>
              </label>
            </div>

            <select
              id="service-select"
              value={serviceId}
              onChange={(e) => handleServiceChange(e.target.value)}
              className="w-full py-3.5 px-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 font-medium text-sm sm:text-base focus:outline-none focus:border-amber-500 focus:bg-white transition-all cursor-pointer"
              required
            >
              <option value="" disabled>
                -- कृपया सेवा चयन गर्नुहोस् (Please select a service) --
              </option>
              {ALL_SERVICES.map((srv) => (
                <option key={srv.id} value={srv.id}>
                  {srv.titleNepali} ({srv.titleEnglish}) — {srv.basePriceText}
                </option>
              ))}
            </select>
          </div>

          {/* STEP 2: DYNAMIC ROUTE PLAN / DAYS / AIRPORT LOGIC & AUTOMATIC LOCATIONS */}
          {selectedService && (
            <div className="p-5 sm:p-6 rounded-2xl bg-gray-50 border border-gray-200 space-y-5 animate-in fade-in duration-200">
              {/* Route Plan Selection for Fixed Routes */}
              {selectedService.type === 'route' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-gray-900 font-['Outfit']">
                      यात्रा योजना रोज्नुहोस् (Plan Selection):
                    </span>
                    <span className="text-xs text-amber-700 font-bold">
                      {selectedService.titleNepali}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {/* One Way Option */}
                    <label
                      onClick={() => setRoutePlan('one-way')}
                      className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${
                        routePlan === 'one-way'
                          ? 'bg-amber-50 border-amber-400 text-gray-900 shadow-xs'
                          : 'bg-white border-gray-200 text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="routePlan"
                          value="one-way"
                          checked={routePlan === 'one-way'}
                          onChange={() => setRoutePlan('one-way')}
                          className="accent-amber-600 w-4 h-4 cursor-pointer"
                        />
                        <div>
                          <div className="font-bold text-sm">One Way (एकतर्फी यात्रा)</div>
                          <div className="text-xs text-gray-500">सुर्खेतबाट गन्तव्य सम्म</div>
                        </div>
                      </div>
                      <div className="text-base font-black text-amber-700 font-['Outfit']">
                        {serviceId === 'surkhet-nepalgunj' && `रु. ${rates.nepalgunjOneWay.toLocaleString('en-IN')}`}
                        {serviceId === 'surkhet-dailekh' && `रु. ${rates.dailekhOneWay.toLocaleString('en-IN')}`}
                        {serviceId === 'surkhet-dhargadhi' && `रु. ${rates.dhargadhiOneWay.toLocaleString('en-IN')}`}
                      </div>
                    </label>

                    {/* Two Way Option */}
                    <label
                      onClick={() => setRoutePlan('two-way')}
                      className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${
                        routePlan === 'two-way'
                          ? 'bg-amber-50 border-amber-400 text-gray-900 shadow-xs'
                          : 'bg-white border-gray-200 text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="routePlan"
                          value="two-way"
                          checked={routePlan === 'two-way'}
                          onChange={() => setRoutePlan('two-way')}
                          className="accent-amber-600 w-4 h-4 cursor-pointer"
                        />
                        <div>
                          <div className="font-bold text-sm">Two Way (दोहोरो यात्रा)</div>
                          <div className="text-xs text-gray-500">जाने र फर्किने दुबै</div>
                        </div>
                      </div>
                      <div className="text-base font-black text-amber-700 font-['Outfit']">
                        {serviceId === 'surkhet-nepalgunj' && `रु. ${rates.nepalgunjTwoWay.toLocaleString('en-IN')}`}
                        {serviceId === 'surkhet-dailekh' && `रु. ${rates.dailekhTwoWay.toLocaleString('en-IN')}`}
                        {serviceId === 'surkhet-dhargadhi' && `रु. ${rates.dhargadhiTwoWay.toLocaleString('en-IN')}`}
                      </div>
                    </label>
                  </div>

                  {/* AUTOMATIC PICKUP & DROP DISPLAY (NO MANUAL ENTRY NEEDED) */}
                  <div className="pt-2">
                    <div className="p-3.5 rounded-xl bg-white border border-gray-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-gray-500 font-medium block">पिकअप स्थान (Pickup Location - Auto):</span>
                        <span className="font-bold text-gray-900 text-sm">{autoLocs.pickup}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 font-medium block">गन्तव्य स्थान (Drop Location - Auto):</span>
                        <span className="font-bold text-gray-900 text-sm">{autoLocs.drop}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Per-Day Services (Surkhet Valley Tour & Wedding Reserve) */}
              {selectedService.type === 'per-day' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-gray-900 font-['Outfit']">
                      दिन संख्या छान्नुहोस् (Number of Days):
                    </span>
                    <span className="text-xs text-amber-700 font-bold">
                      दर: रु. ५,००० / दिन (Per Day)
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                    {[1, 2, 3, 4, 5].map((d) => (
                      <button
                        type="button"
                        key={d}
                        onClick={() => setNumberOfDays(d)}
                        className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                          numberOfDays === d
                            ? 'bg-amber-500 text-white shadow-xs'
                            : 'bg-white text-gray-700 border border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        {d} {d === 1 ? 'दिन (1 Day)' : `दिन (${d} Days)`} — रु. {(5000 * d).toLocaleString('en-IN')}
                      </button>
                    ))}
                  </div>

                  {/* Context field for Tour / Wedding venue */}
                  <div>
                    <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-amber-600" />
                      <span>
                        {selectedService.id === 'valley-tour'
                          ? 'सुरु हुने स्थान वा होटेल (Starting Location / Hotel in Surkhet)'
                          : 'विवाह मण्डप वा घरको ठेगाना (Wedding Venue / House Address in Surkhet)'}
                      </span>
                    </label>
                    <input
                      type="text"
                      placeholder="उदा: वीरेन्द्रनगर-६, सुर्खेत / होटेलको नाम"
                      value={venueOrHotel}
                      onChange={(e) => setVenueOrHotel(e.target.value)}
                      className="w-full py-2.5 px-3 rounded-xl bg-white border border-gray-300 text-gray-900 text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              )}

              {/* Airport Pickup & Drop (Always exactly 1,000) */}
              {selectedService.type === 'airport' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl bg-white border border-amber-300 gap-3 shadow-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold border border-amber-200">
                        SKH
                      </div>
                      <div>
                        <div className="text-sm font-bold text-gray-900">सुर्खेत विमानस्थल पिकअप र ड्रप</div>
                        <div className="text-xs text-amber-800 font-semibold">निश्चित फिक्स दर (Fixed Rate)</div>
                      </div>
                    </div>
                    <div className="text-left sm:text-right">
                      <span className="text-xs text-gray-500 block">कुल रकम (Total Amount)</span>
                      <span className="text-xl font-black text-amber-700 font-['Outfit']">
                        रु. {rates.airportPickupDrop.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>

                  {/* Airport specific fields only */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                        <Plane className="w-3.5 h-3.5 text-amber-600" />
                        <span>सेवा प्रकार (Airport Service Type)</span>
                      </label>
                      <select
                        value={airportTripType}
                        onChange={(e) => setAirportTripType(e.target.value as 'pickup' | 'drop')}
                        className="w-full py-2.5 px-3 rounded-xl bg-white border border-gray-300 text-gray-900 text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                      >
                        <option value="pickup">विमानस्थलबाट पिकअप (Airport to Hotel/Home)</option>
                        <option value="drop">विमानस्थल सम्म ड्रप (Hotel/Home to Airport)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                        <Plane className="w-3.5 h-3.5 text-amber-600" />
                        <span>उडान नम्बर वा एयरलाइन्स (Flight No / Airline - ऐच्छिक)</span>
                      </label>
                      <input
                        type="text"
                        placeholder="उदा: Buddha Air U4 133 / Yeti Air"
                        value={flightInfo}
                        onChange={(e) => setFlightInfo(e.target.value)}
                        className="w-full py-2.5 px-3 rounded-xl bg-white border border-gray-300 text-gray-900 text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-amber-600" />
                        <span>सुर्खेतको होटेल वा घर ठेगाना (Hotel / Home Location in Surkhet)</span>
                      </label>
                      <input
                        type="text"
                        placeholder="उदा: होटेल शुभ / वीरेन्द्रनगर-४, सुर्खेत"
                        value={venueOrHotel}
                        onChange={(e) => setVenueOrHotel(e.target.value)}
                        className="w-full py-2.5 px-3 rounded-xl bg-white border border-gray-300 text-gray-900 text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 3: SCHEDULE */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-amber-500 text-white font-extrabold flex items-center justify-center text-xs">
                २
              </div>
              <span className="text-base font-bold text-gray-900 font-['Outfit']">
                मिति र समय (Trip Schedule) <span className="text-amber-600">*</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-amber-600" />
                  <span>यात्रा मिति (Date) *</span>
                </label>
                <input
                  type="date"
                  value={pickupDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setPickupDate(e.target.value)}
                  className="w-full py-3 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                  <span>पिकअप समय (Time)</span>
                </label>
                <input
                  type="time"
                  value={pickupTime}
                  onChange={(e) => setPickupTime(e.target.value)}
                  className="w-full py-3 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-amber-600" />
                  <span>यात्रु संख्या (Passengers)</span>
                </label>
                <select
                  value={passengerCount}
                  onChange={(e) => setPassengerCount(Number(e.target.value))}
                  className="w-full py-3 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white cursor-pointer"
                >
                  <option value={1}>१ जना (1 Passenger)</option>
                  <option value={2}>२ जना (2 Passengers)</option>
                  <option value={3}>३ जना (3 Passengers)</option>
                  <option value={4}>४ जना (4 Passengers - Full)</option>
                </select>
              </div>
            </div>
          </div>

          {/* STEP 4: CUSTOMER CONTACT INFO */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-amber-500 text-white font-extrabold flex items-center justify-center text-xs">
                ३
              </div>
              <span className="text-base font-bold text-gray-900 font-['Outfit']">
                तपाईंको सम्पर्क विवरण (Contact Details) <span className="text-amber-600">*</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-600" />
                  <span>पूरा नाम (Full Name) *</span>
                </label>
                <input
                  type="text"
                  placeholder="उदा: रमेश अधिकारी"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full py-3 px-3.5 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-amber-600" />
                  <span>मोबाइल / फोन नम्बर *</span>
                </label>
                <input
                  type="tel"
                  placeholder="उदा: 9802581402"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full py-3 px-3.5 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-amber-600" />
                  <span>इमेल ठेगाना (Email - ऐच्छिक)</span>
                </label>
                <input
                  type="email"
                  placeholder="उदा: yourname@gmail.com"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full py-3 px-3.5 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div className="sm:col-span-2 lg:col-span-3">
                <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-amber-600" />
                  <span>थप अनुरोध वा सुझाव (Special Requests / Notes)</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="उदा: लगेज सम्बन्धी जानकारी वा विशेष समय अनुरोध..."
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  className="w-full py-2.5 px-3.5 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white resize-none"
                />
              </div>
            </div>
          </div>

          {/* ================================================== */}
          {/* STEP 9: REAL-TIME BOOKING SUMMARY (EXACT REQUIREMENTS) */}
          {/* ================================================== */}
          <div className="rounded-2xl p-6 sm:p-7 bg-amber-50/60 border border-amber-300/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-amber-200/80 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-700" />
                <span className="text-lg font-extrabold text-gray-900 font-['Outfit']">
                  तपाईंको चयन (Your Selection)
                </span>
              </div>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-white text-gray-800 border border-amber-200">
                BYD ATTO 2
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 text-sm">
              {/* Selected Service */}
              <div className="p-3 rounded-xl bg-white border border-gray-200">
                <div className="text-xs text-gray-500">सेवा (Service):</div>
                <div className="font-bold text-gray-900 mt-1">
                  {serviceId ? pricing.serviceTitleNepali : 'कृपया सेवा चयन गर्नुहोस्'}
                </div>
              </div>

              {/* Selected Trip Type */}
              <div className="p-3 rounded-xl bg-white border border-gray-200">
                <div className="text-xs text-gray-500">यात्रा प्रकार (Trip Type):</div>
                <div className="font-bold text-gray-900 mt-1">
                  {serviceId ? pricing.tripType : '—'}
                </div>
              </div>

              {/* Selected Plan */}
              <div className="p-3 rounded-xl bg-white border border-gray-200">
                <div className="text-xs text-gray-500">योजना (Plan):</div>
                <div className="font-bold text-gray-900 mt-1">
                  {serviceId ? pricing.planDescription : '—'}
                </div>
              </div>

              {/* Selected Days (if applicable) */}
              <div className="p-3 rounded-xl bg-white border border-gray-200">
                <div className="text-xs text-gray-500">दिन (Days):</div>
                <div className="font-bold text-gray-900 mt-1">
                  {selectedService?.type === 'per-day'
                    ? pricing.daysDescription || `${numberOfDays} दिन`
                    : 'लागु हुँदैन (N/A)'}
                </div>
              </div>
            </div>

            {/* Total Calculated Amount */}
            <div className="pt-3 border-t border-amber-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-gray-600 block uppercase tracking-wider">
                  कुल रकम (Total Calculated Amount):
                </span>
                <span className="text-2xl sm:text-4xl font-black text-amber-700 font-['Outfit']">
                  {serviceId && pricing.amount !== null ? (
                    `रु. ${pricing.amount.toLocaleString('en-IN')}`
                  ) : (
                    <span className="text-lg sm:text-xl text-gray-500 font-medium">
                      कृपया सेवा चयन गर्नुहोस्
                    </span>
                  )}
                </span>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting || !serviceId}
                className={`py-4 px-8 rounded-xl font-extrabold text-base tracking-wide shadow-sm flex items-center justify-center gap-3 transition-all cursor-pointer ${
                  !serviceId || isSubmitting
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed border border-gray-300'
                    : 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs hover:scale-[1.01] active:scale-95'
                }`}
              >
                {isSubmitting ? (
                  <span>प्रक्रिया हुँदैछ...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-white" />
                    <span>कार रिजर्भ पुष्टि गर्नुहोस्</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Confirmation Modal */}
      {confirmedBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white border border-emerald-400 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600 mb-4">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-xl sm:text-2xl font-extrabold text-center text-gray-900 font-['Outfit']">
              बुकिङ सफलतापूर्वक पेश भयो!
            </h3>
            <p className="text-xs sm:text-sm text-center text-gray-600 mt-1">
              SURKHET LUXURY CAR RESERVE SEWA
            </p>

            {/* Reference Card */}
            <div className="my-6 p-4 rounded-2xl bg-gray-50 border border-gray-200 space-y-2 text-sm">
              <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                <span className="text-xs text-gray-500 font-medium">बुकिङ नम्बर (Ref ID):</span>
                <span className="font-mono font-bold text-amber-700 text-base">
                  {confirmedBooking.referenceId}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500">ग्राहकको नाम:</span>
                <span className="font-semibold text-gray-900">{confirmedBooking.customerName}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500">सेवा:</span>
                <span className="font-semibold text-gray-900">{confirmedBooking.serviceName}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500">यात्रा प्रकार:</span>
                <span className="font-semibold text-gray-900">{confirmedBooking.tripType}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500">पिकअप मिति:</span>
                <span className="font-semibold text-gray-900">
                  {confirmedBooking.pickupDate} ({confirmedBooking.pickupTime})
                </span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                <span className="font-bold text-gray-700">कुल रकम (Total Amount):</span>
                <span className="font-black text-amber-700 text-lg font-['Outfit']">
                  रु. {confirmedBooking.amount.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <p className="text-xs text-center text-gray-600 mb-6">
              हाम्रो आधिकारिक टोलीले तपाईंको फोन नम्बर{' '}
              <strong className="text-amber-700">{confirmedBooking.customerPhone}</strong> मा छिट्टै सम्पर्क गरी
              चालक र गाडीको विवरण पठाउनेछ।
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={`https://wa.me/9779802581402?text=${encodeURIComponent(
                  `नमस्ते, मैले सुर्खेत लक्जरी कार रिजर्भ Sewa मा BYD ATTO 2 बुक गरेको छु। बुकिङ नम्बर: ${confirmedBooking.referenceId}, सेवा: ${confirmedBooking.serviceName}, रकम: रु. ${confirmedBooking.amount}`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm text-center shadow-xs transition-all"
              >
                ह्वाट्सएपमा सम्पर्क गर्नुहोस्
              </a>

              <button
                onClick={handleResetForm}
                className="py-3 px-6 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold text-xs sm:text-sm transition-all cursor-pointer"
              >
                बन्द गर्नुहोस् (Close)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
