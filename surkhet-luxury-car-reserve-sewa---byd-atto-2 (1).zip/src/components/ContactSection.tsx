import React from 'react';
import { Phone, MapPin, Mail, MessageCircle, Clock, ExternalLink } from 'lucide-react';
import { BusinessSettings } from '../types/index.ts';

interface ContactSectionProps {
  settings?: BusinessSettings;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ settings }) => {
  const phone = settings?.phone || '9802581402';
  const email = settings?.email || 'info@surkhetluxurycar.com';
  const address = settings?.address || 'वीरेन्द्रनगर, सुर्खेत';
  const whatsapp = settings?.whatsapp || '9802581402';
  const facebookUrl = settings?.facebookUrl || 'https://facebook.com';
  const tiktokUrl = settings?.tiktokUrl || 'https://tiktok.com';
  const instagramUrl = settings?.instagramUrl || 'https://instagram.com';

  return (
    <section id="contact" className="py-16 sm:py-22 bg-gray-50/70 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider mb-3">
            हामीलाई सम्पर्क गर्नुहोस्
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 tracking-tight font-['Outfit']">
            Contact <span className="text-amber-600">SURKHET LUXURY CAR</span>
          </h2>
          <p className="mt-3 text-gray-600 text-base sm:text-lg">
            BYD ATTO 2 रिजर्भ सम्बन्धी कुनै पनि जानकारी वा तत्काल बुकिङका लागि हामीलाई सम्पर्क गर्नुहोस्।
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Card 1: Phone & Call */}
          <div className="p-6 sm:p-7 rounded-2xl bg-white border border-gray-200 hover:border-amber-400 transition-all shadow-xs hover:shadow-md flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mb-4">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] mb-1">
                फोन सम्पर्क (Phone Call)
              </h3>
              <p className="text-xs text-gray-500 mb-4">
                २४ सै घण्टा तत्काल कल तथा सोधपुछ उपलब्ध
              </p>
              <div className="space-y-1.5">
                <a
                  href={`tel:${phone.replace(/[^0-9]/g, '')}`}
                  className="block text-2xl font-black text-amber-700 hover:text-amber-800 font-['Outfit']"
                >
                  {phone}
                </a>
                <span className="text-xs text-emerald-700 font-semibold block">
                  ✓ अन-कल बुकिङ २४/७ खुल्ला
                </span>
              </div>
            </div>

            <div className="pt-5 mt-5 border-t border-gray-100">
              <a
                href={`tel:${phone.replace(/[^0-9]/g, '')}`}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-extrabold text-xs sm:text-sm text-center flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg active:scale-98"
                title={`सिधा कल: ${phone}`}
              >
                <Phone className="w-4 h-4 fill-current" />
                <span>सिधा कल गर्नुहोस् ({phone})</span>
              </a>
            </div>
          </div>

          {/* Card 2: WhatsApp & Messaging */}
          <div className="p-6 sm:p-7 rounded-2xl bg-white border border-gray-200 hover:border-emerald-400 transition-all shadow-xs hover:shadow-md flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 mb-4">
                <MessageCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] mb-1">
                ह्वाट्सएप (WhatsApp Chat)
              </h3>
              <p className="text-xs text-gray-500 mb-4">
                सजिलो र छिटो म्यासेज मार्फत सिट तथा गाडी बुक
              </p>
              <div className="text-xl font-bold text-emerald-700 font-['Outfit']">
                {whatsapp}
              </div>
              <p className="text-xs text-gray-500 mt-2">
                स्थान, मिति र यात्रु संख्या लेखेर तुरुन्त म्यासेज गर्नुहोस्।
              </p>
            </div>

            <div className="pt-5 mt-5 border-t border-gray-100">
              <a
                href={`https://wa.me/977${whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  'नमस्ते, म सुर्खेत लक्जरी कार रिजर्भ Sewa को BYD ATTO 2 बुक गर्न चाहन्छु।'
                )}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm text-center block transition-all shadow-xs"
              >
                ह्वाट्सएपमा च्याट गर्नुहोस्
              </a>
            </div>
          </div>

          {/* Card 3: Location & Social Media */}
          <div className="p-6 sm:p-7 rounded-2xl bg-white border border-gray-200 hover:border-amber-400 transition-all shadow-xs hover:shadow-md flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mb-4">
                <MapPin className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] mb-1">
                कार्यालय ठेगाना (Location)
              </h3>
              <p className="text-sm font-semibold text-gray-800 leading-relaxed mb-4">
                {address}
              </p>

              {/* Social Media Links: TikTok, Facebook, Instagram */}
              <div className="pt-2">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider block mb-2">
                  सामाजिक सञ्जाल (Social Media):
                </span>
                <div className="flex items-center gap-2">
                  {/* TikTok */}
                  <a
                    href={tiktokUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-gray-50 border border-gray-200 hover:border-amber-400 text-xs font-bold text-gray-700 hover:text-amber-700 flex items-center gap-1.5 transition-all"
                  >
                    <span>TikTok</span>
                    <ExternalLink className="w-3 h-3 text-gray-400" />
                  </a>

                  {/* Facebook */}
                  <a
                    href={facebookUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-gray-50 border border-gray-200 hover:border-amber-400 text-xs font-bold text-gray-700 hover:text-amber-700 flex items-center gap-1.5 transition-all"
                  >
                    <span>Facebook</span>
                    <ExternalLink className="w-3 h-3 text-gray-400" />
                  </a>

                  {/* Instagram */}
                  <a
                    href={instagramUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-gray-50 border border-gray-200 hover:border-amber-400 text-xs font-bold text-gray-700 hover:text-amber-700 flex items-center gap-1.5 transition-all"
                  >
                    <span>Instagram</span>
                    <ExternalLink className="w-3 h-3 text-gray-400" />
                  </a>
                </div>
              </div>
            </div>

            <div className="pt-5 mt-5 border-t border-gray-100">
              <div className="text-xs text-gray-600 flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                <span>कार्यालय: २४ घण्टा / ३६५ दिन खुल्ला</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
