import React, { useState, useEffect } from 'react';
import { Shield, Lock, User, AlertCircle, X, CheckCircle, RefreshCw, KeyRound, UserPlus, CheckCircle2 } from 'lucide-react';
import { api } from '../../services/api.ts';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (username: string) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [slotLocked, setSlotLocked] = useState(false);
  const [isSetupNeeded, setIsSetupNeeded] = useState(false);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      checkSetupAndSlot();
    }
  }, [isOpen]);

  const checkSetupAndSlot = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.getSetupStatus();
      if (res.success) {
        const needsSetup = !res.isConfigured;
        setIsSetupNeeded(needsSetup);
        setSlotLocked(!!res.hasActiveSlot);
        if (needsSetup) {
          setUsername('admin');
        } else {
          setUsername('');
        }
      }
    } catch (err) {
      console.error('Error checking setup status:', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent, forceReset = false) => {
    e.preventDefault();
    setErrorMessage(null);
    setResetSuccess(null);

    if (isSetupNeeded) {
      if (!username.trim()) {
        setErrorMessage('कृपया युजरनेम राख्नुहोस्');
        return;
      }
      if (password.length < 5) {
        setErrorMessage('पासवर्ड कम्तीमा ५ क्यारेक्टरको हुनुपर्छ');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMessage('पासवर्ड र कन्फर्म पासवर्ड मिलेन');
        return;
      }

      setIsLoading(true);
      try {
        const setupRes = await api.setupAdmin(username.trim(), password);
        if (setupRes.success) {
          setIsSetupNeeded(false);
          onLoginSuccess(setupRes.username || username.trim());
          return;
        } else {
          setErrorMessage(setupRes.error || 'खाता सिर्जना गर्न सकिएन।');
        }
      } catch (err: any) {
        setErrorMessage(err.message || 'खाता सिर्जना गर्दा समस्या आयो।');
      } finally {
        setIsLoading(false);
      }
      return;
    }

    // Normal Login
    setIsLoading(true);
    try {
      const res = await api.login(username, password, forceReset);

      if (res.success && res.username) {
        onLoginSuccess(res.username);
      } else if (res.slotLocked) {
        setSlotLocked(true);
        setErrorMessage(
          'Single-Admin Slot हाल सक्रिय छ। पुरानो सेसन हटाएर लगइन गर्न तलको पासवर्ड राखेर "Reset Slot" थिच्नुहोस्।'
        );
      } else {
        setErrorMessage(res.error || 'लगइन असफल भयो। युजरनेम वा पासवर्ड जाँच्नुहोस्।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'लगइन गर्दा समस्या आयो।');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForceResetSlot = async () => {
    setErrorMessage(null);
    setResetSuccess(null);
    if (!password) {
      setErrorMessage('स्लट रिसेट गर्न पासवर्ड राख्नुहोस्।');
      return;
    }
    setIsLoading(true);
    try {
      const res = await api.resetSlot(password);
      if (res.success) {
        setSlotLocked(false);
        setResetSuccess('Admin Slot रिसेट भयो! अब सिधै लगइन गर्नुहोस्।');
      } else {
        setErrorMessage(res.error || 'स्लट रिसेट गर्न पासवर्ड मिलेन।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'स्लट रिसेट गर्न सकिएन।');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-gray-200 rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-500 hover:text-gray-900 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title & Icon */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto text-amber-600 mb-3 shadow-xs">
            {isSetupNeeded ? <UserPlus className="w-7 h-7" /> : <Shield className="w-7 h-7" />}
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-2 bg-amber-100 text-amber-900 border border-amber-200">
            {isSetupNeeded ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>१ एकल स्लट खुला (1 Slot Open)</span>
              </>
            ) : (
              <>
                <Lock className="w-3 h-3 text-amber-700" />
                <span>Single-Admin Slot सुरक्षित (Locked)</span>
              </>
            )}
          </div>

          <h3 className="text-2xl font-extrabold text-gray-900 font-['Outfit']">
            {isSetupNeeded ? 'एडमिन खाता सिर्जना गर्नुहोस्' : 'एडमिन पोर्टल लगइन'}
          </h3>
          <p className="text-xs text-gray-500 mt-1 leading-relaxed">
            {isSetupNeeded
              ? 'तपाईंको आफ्नै युजरनेम र पासवर्ड राखेर व्यवस्थापक खाता बनाउनुहोस्। एकपटक बनेपछि अरू कसैले पनि नयाँ खाता बनाउन पाउने छैन।'
              : 'SURKHET LUXURY CAR RESERVE SEWA • व्यवस्थापक नियन्त्रण प्यानल'}
          </p>
        </div>

        {/* Status Banners */}
        {slotLocked && !resetSuccess && (
          <div className="mb-4 p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">सक्रिय सेसन सूचना:</span> एडमिन स्लट हाल अर्को ट्याब वा डिभाइसमा सक्रिय छ। पुरानो सेसन हटाएर लगइन गर्न पासवर्ड राखेर तल "Reset Admin Slot" थिच्नुहोस्।
            </div>
          </div>
        )}

        {resetSuccess && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{resetSuccess}</span>
          </div>
        )}

        {errorMessage && (
          <div className="mb-4 p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1 font-medium">{errorMessage}</div>
          </div>
        )}

        <form onSubmit={(e) => handleSubmit(e, false)} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-amber-600" />
              <span>{isSetupNeeded ? 'नयाँ युजरनेम (Username)' : 'युजरनेम (Username)'}</span>
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder={isSetupNeeded ? 'तपाईंको युजरनेम (उदा. admin)' : 'युजरनेम'}
              className="w-full py-3 px-3.5 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
              required
              autoFocus
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-amber-600" />
              <span>{isSetupNeeded ? 'नयाँ पासवर्ड (कम्तीमा ५ अक्षर)' : 'पासवर्ड (Password)'}</span>
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full py-3 px-3.5 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
              required
            />
          </div>

          {isSetupNeeded && (
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
                <span>पासवर्ड पुष्टि गर्नुहोस् (Confirm Password)</span>
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full py-3 px-3.5 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                required
              />
            </div>
          )}

          <div className="pt-2 space-y-2">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-sm tracking-wide shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <span>कृपया पर्खनुहोस्...</span>
              ) : isSetupNeeded ? (
                <>
                  <UserPlus className="w-4 h-4" />
                  <span>खाता सिर्जना गरी लगइन गर्नुहोस्</span>
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>लगइन गर्नुहोस् (Login)</span>
                </>
              )}
            </button>

            {slotLocked && !isSetupNeeded && (
              <button
                type="button"
                onClick={handleForceResetSlot}
                disabled={isLoading || !password}
                className="w-full py-2.5 px-4 rounded-xl bg-gray-100 hover:bg-gray-200 text-amber-800 border border-amber-300 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset Admin Slot (Force Override)</span>
              </button>
            )}
          </div>
        </form>

        <div className="mt-6 pt-4 border-t border-gray-100 text-center text-gray-400 text-xs">
          {isSetupNeeded
            ? 'यो १ एकल स्लट हो। तपाईंले दर्ता गरेपछि नयाँ दर्ता स्थायी रूपमा बन्द हुनेछ।'
            : 'Single-Admin Slot Security Enforced • Only 1 admin account permitted'}
        </div>
      </div>
    </div>
  );
};
