import React, { useState, useEffect } from 'react';
import {
  X,
  LogOut,
  Calendar,
  DollarSign,
  Image,
  Settings,
  Shield,
  Search,
  CheckCircle,
  Clock,
  AlertTriangle,
  Trash2,
  Phone,
  RefreshCw,
  Plus,
  Save,
  KeyRound,
  ExternalLink,
  Car,
  Check,
  Database,
  Copy,
} from 'lucide-react';
import {
  BookingItem,
  GalleryPhoto,
  ServiceRates,
  BusinessSettings,
  DashboardStats,
  BookingStatus,
} from '../../types/index.ts';
import { api } from '../../services/api.ts';
import { BYD_ATTO_2_IMAGES } from '../../constants/images.ts';
import { BydImage } from '../BydImage.tsx';
import {
  SUPABASE_PROJECT_ID,
  SUPABASE_URL,
  SUPABASE_SETUP_SQL,
  testSupabaseConnection,
} from '../../services/supabase.ts';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
  currentRates: ServiceRates;
  onRatesUpdated: (rates: ServiceRates) => void;
  onSettingsUpdated: (settings: BusinessSettings) => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  onLogout,
  currentRates,
  onRatesUpdated,
  onSettingsUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'bookings' | 'rates' | 'gallery' | 'settings'>('bookings');

  // Data states
  const [bookings, setBookings] = useState<BookingItem[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [gallery, setGallery] = useState<GalleryPhoto[]>([]);
  const [editingRates, setEditingRates] = useState<ServiceRates>(currentRates);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings>({
    businessNameNepali: 'सुर्खेत लक्जरी कार रिजर्भ सेवा',
    businessNameEnglish: 'SURKHET LUXURY CAR RESERVE SEWA',
    phone: '9802581402',
    altPhone: '9802581402',
    email: 'info@surkhetluxurycar.com',
    address: 'वीरेन्द्रनगर, सुर्खेत',
    whatsapp: '9802581402',
    facebookUrl: 'https://facebook.com',
    tiktokUrl: 'https://tiktok.com',
    instagramUrl: 'https://instagram.com',
    tagline: 'कर्णालीको पहिलो १००% विद्युतीय प्रिमियम BYD ATTO 2 लक्जरी कार सेवा',
  });

  // UI state
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [rateSaveSuccess, setRateSaveSuccess] = useState<string | null>(null);
  const [settingsSuccess, setSettingsSuccess] = useState<string | null>(null);
  const [gallerySuccess, setGallerySuccess] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState<string | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedBooking, setSelectedBooking] = useState<BookingItem | null>(null);

  // New gallery photo state (BYD ATTO 2 Only)
  const [newPhotoTitle, setNewPhotoTitle] = useState('');
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoCategory, setNewPhotoCategory] = useState<'exterior' | 'interior' | 'feature'>('exterior');
  const [newPhotoCaption, setNewPhotoCaption] = useState('');

  // Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Supabase state
  const [supabaseStatus, setSupabaseStatus] = useState<any>(null);
  const [isCheckingSupabase, setIsCheckingSupabase] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadAllAdminData();
      checkSupabase();
    }
  }, [isOpen]);

  const checkSupabase = async () => {
    setIsCheckingSupabase(true);
    try {
      const res = await api.getSupabaseStatus();
      if (res.success && res.status) {
        setSupabaseStatus(res.status);
      } else {
        const clientRes = await testSupabaseConnection();
        setSupabaseStatus(clientRes);
      }
    } catch {
      const clientRes = await testSupabaseConnection();
      setSupabaseStatus(clientRes);
    } finally {
      setIsCheckingSupabase(false);
    }
  };

  const handleSyncToSupabase = async () => {
    setIsSyncing(true);
    setSyncMessage(null);
    try {
      const res = await api.syncAllToSupabase();
      if (res.success) {
        setSyncMessage(`सफलतापूर्वक ${res.totalBookings || bookings.length} वटा बुकिङ Supabase मा सिंक गरियो!`);
      } else {
        setSyncMessage(`सिंक नोट: ${res.error || 'अपूर्ण'}`);
      }
    } catch (err: any) {
      setSyncMessage(`त्रुटि: ${err.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const copySqlToClipboard = () => {
    navigator.clipboard.writeText(SUPABASE_SETUP_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const loadAllAdminData = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const [bookingsRes, statsRes, galleryRes, ratesRes, settingsRes] = await Promise.all([
        api.getBookings(),
        api.getDashboardStats(),
        api.getGallery(),
        api.getRates(),
        api.getSettings(),
      ]);

      if (bookingsRes.success && bookingsRes.bookings) setBookings(bookingsRes.bookings);
      if (statsRes.success && statsRes.stats) setStats(statsRes.stats);
      if (galleryRes.success && galleryRes.gallery) setGallery(galleryRes.gallery);
      if (ratesRes.success && ratesRes.rates) {
        setEditingRates(ratesRes.rates);
        onRatesUpdated(ratesRes.rates);
      }
      if (settingsRes.success && settingsRes.settings) {
        setBusinessSettings(settingsRes.settings);
        onSettingsUpdated(settingsRes.settings);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'डाटा लोड गर्न सकिएन');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  // Booking handlers
  const handleUpdateBookingStatus = async (id: string, status: BookingStatus) => {
    try {
      const res = await api.updateBooking(id, { status });
      if (res.success && res.booking) {
        setBookings((prev) => prev.map((b) => (b.id === id ? res.booking! : b)));
        if (selectedBooking && selectedBooking.id === id) {
          setSelectedBooking(res.booking);
        }
      }
    } catch (err: any) {
      alert(err.message || 'Error updating status');
    }
  };

  const handleDeleteBooking = async (id: string) => {
    if (!window.confirm('के तपाईं यो बुकिङ मेटाउन निश्चित हुनुहुन्छ? (Delete booking?)')) return;
    try {
      const res = await api.deleteBooking(id);
      if (res.success) {
        setBookings((prev) => prev.filter((b) => b.id !== id));
        if (selectedBooking && selectedBooking.id === id) setSelectedBooking(null);
      }
    } catch (err: any) {
      alert(err.message || 'Error deleting booking');
    }
  };

  // Rates handlers
  const handleSaveRates = async (e: React.FormEvent) => {
    e.preventDefault();
    setRateSaveSuccess(null);
    setErrorMessage(null);
    try {
      const res = await api.updateRates(editingRates);
      if (res.success && res.rates) {
        setEditingRates(res.rates);
        onRatesUpdated(res.rates);
        setRateSaveSuccess('नयाँ भाडा दरहरू सफलतापूर्वक सुरक्षित गरियो!');
        setTimeout(() => setRateSaveSuccess(null), 3000);
      } else {
        setErrorMessage(res.error || 'दर सुरक्षित गर्न सकिएन');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'दर सुरक्षित गर्न सकिएन');
    }
  };

  const handleResetRates = async () => {
    if (!window.confirm('के तपाईं सबै दरहरू सुरुवाती अवस्थामा फर्काउन चाहनुहुन्छ? (Reset all rates to defaults?)')) return;
    try {
      const res = await api.resetRates();
      if (res.success && res.rates) {
        setEditingRates(res.rates);
        onRatesUpdated(res.rates);
        setRateSaveSuccess('दरहरू प्रारम्भिक अवस्थामा रिसेट गरियो!');
        setTimeout(() => setRateSaveSuccess(null), 3000);
      }
    } catch (err: any) {
      alert(err.message || 'Reset error');
    }
  };

  // Gallery handlers (BYD ATTO 2 Only)
  const handleAddGalleryPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    setGallerySuccess(null);
    setErrorMessage(null);

    if (!newPhotoTitle || !newPhotoUrl) {
      setErrorMessage('तस्बिरको शीर्षक र URL अनिवार्य छ।');
      return;
    }

    try {
      const res = await api.addGalleryPhoto({
        title: newPhotoTitle,
        imageUrl: newPhotoUrl,
        category: newPhotoCategory,
        caption: newPhotoCaption || 'BYD ATTO 2 Luxury Electric SUV',
      });

      if (res.success && res.photo) {
        setGallery((prev) => [res.photo!, ...prev]);
        setNewPhotoTitle('');
        setNewPhotoUrl('');
        setNewPhotoCaption('');
        setGallerySuccess('BYD ATTO 2 फोटो सफलतापूर्वक थपियो!');
        setTimeout(() => setGallerySuccess(null), 3000);
      } else {
        setErrorMessage(res.error || 'फोटो थप्न सकिएन');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'फोटो थप्न सकिएन');
    }
  };

  const handleDeletePhoto = async (id: string) => {
    if (!window.confirm('के तपाईं यो फोटो मेटाउन चाहनुहुन्छ?')) return;
    try {
      const res = await api.deleteGalleryPhoto(id);
      if (res.success) {
        setGallery((prev) => prev.filter((p) => p.id !== id));
      }
    } catch (err: any) {
      alert(err.message || 'Delete photo error');
    }
  };

  // Password handler
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordSuccess(null);
    setErrorMessage(null);

    if (newPassword !== confirmPassword) {
      setErrorMessage('नयाँ पासवर्डहरू मिलेनन्।');
      return;
    }

    if (newPassword.length < 4) {
      setErrorMessage('पासवर्ड कम्तिमा ४ अक्षरको हुनुपर्छ।');
      return;
    }

    try {
      const res = await api.changePassword(currentPassword, newPassword);
      if (res.success) {
        setPasswordSuccess('पासवर्ड सफलतापूर्वक परिवर्तन भयो!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        setTimeout(() => setPasswordSuccess(null), 3000);
      } else {
        setErrorMessage(res.error || 'पासवर्ड परिवर्तन असफल');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error changing password');
    }
  };

  // Settings handler
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsSuccess(null);
    setErrorMessage(null);

    try {
      const res = await api.updateSettings(businessSettings);
      if (res.success && res.settings) {
        setBusinessSettings(res.settings);
        onSettingsUpdated(res.settings);
        setSettingsSuccess('व्यावसायिक विवरणहरू सुरक्षित गरियो!');
        setTimeout(() => setSettingsSuccess(null), 3000);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error saving settings');
    }
  };

  // Filtered Bookings
  const filteredBookings = bookings.filter((b) => {
    const matchesSearch =
      b.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.customerPhone.includes(searchQuery) ||
      b.referenceId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.serviceName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-gray-200 rounded-3xl max-w-6xl w-full h-[95vh] sm:h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* TOP BAR */}
        <div className="px-5 py-4 bg-gray-50 border-b border-gray-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-gray-900 text-base sm:text-lg font-['Outfit']">
                  Admin Control Panel
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                  Single-Slot Active
                </span>
              </div>
              <p className="text-xs text-gray-500">
                SURKHET LUXURY CAR RESERVE SEWA • BYD ATTO 2 Control Center
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={loadAllAdminData}
              disabled={isLoading}
              className="p-2 rounded-xl bg-white hover:bg-gray-100 text-gray-700 border border-gray-200 cursor-pointer shadow-xs"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>

            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white hover:bg-gray-100 text-gray-500 hover:text-gray-900 border border-gray-200 cursor-pointer shadow-xs"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* TABS NAVIGATION */}
        <div className="px-5 bg-white border-b border-gray-200 flex items-center gap-2 overflow-x-auto shrink-0 py-2.5">
          <button
            onClick={() => setActiveTab('bookings')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'bookings'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>बुकिङहरू (Bookings - {bookings.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('rates')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'rates'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>दररेट व्यवस्थापन (Rates Management)</span>
          </button>

          <button
            onClick={() => setActiveTab('gallery')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'gallery'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Image className="w-4 h-4" />
            <span>BYD ATTO 2 ग्यालरी ({gallery.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'settings'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>सेटिङ्स तथा पासवर्ड (Settings)</span>
          </button>
        </div>

        {/* MAIN BODY AREA */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gray-50/70">
          {/* TAB 1: BOOKINGS */}
          {activeTab === 'bookings' && (
            <div className="space-y-6">
              {/* Stats overview banner */}
              {stats && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-4 rounded-xl bg-white border border-gray-200 shadow-xs">
                    <span className="text-xs text-gray-500 font-medium">कुल बुकिङ (Total)</span>
                    <div className="text-xl sm:text-2xl font-extrabold text-gray-900 font-['Outfit'] mt-1">
                      {stats.totalBookings}
                    </div>
                  </div>
                  <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 shadow-xs">
                    <span className="text-xs text-amber-800 font-semibold">पेन्डिङ (Pending)</span>
                    <div className="text-xl sm:text-2xl font-extrabold text-amber-700 font-['Outfit'] mt-1">
                      {stats.pendingBookings}
                    </div>
                  </div>
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 shadow-xs">
                    <span className="text-xs text-emerald-800 font-semibold">पुष्टि भएको (Confirmed)</span>
                    <div className="text-xl sm:text-2xl font-extrabold text-emerald-700 font-['Outfit'] mt-1">
                      {stats.confirmedBookings}
                    </div>
                  </div>
                  <div className="p-4 rounded-xl bg-white border border-gray-200 shadow-xs">
                    <span className="text-xs text-gray-500 font-medium">कुल कारोबार (Revenue)</span>
                    <div className="text-xl sm:text-2xl font-extrabold text-amber-600 font-['Outfit'] mt-1">
                      रु. {stats.totalRevenue.toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>
              )}

              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    placeholder="नाम, फोन, वा Ref ID खोज्नुहोस्..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full py-2.5 pl-9 pr-3 rounded-xl bg-white border border-gray-300 text-xs sm:text-sm text-gray-900 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
                  {['all', 'pending', 'confirmed', 'completed', 'cancelled'].map((st) => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer whitespace-nowrap ${
                        statusFilter === st
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bookings List */}
              {filteredBookings.length === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-white border border-gray-200 shadow-xs">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <h4 className="text-gray-900 font-bold text-base">कुनै बुकिङ फेला परेन</h4>
                  <p className="text-xs text-gray-500 mt-1">नयाँ बुकिङहरू यहाँ सूचीबद्ध हुनेछन्।</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {filteredBookings.map((b) => (
                    <div
                      key={b.id}
                      className="p-4 sm:p-5 rounded-2xl bg-white border border-gray-200 hover:border-amber-400 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs"
                    >
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-gray-100 text-gray-800 border border-gray-200">
                            {b.referenceId}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                              b.status === 'confirmed'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : b.status === 'pending'
                                ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                : b.status === 'completed'
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-red-50 text-red-700 border border-red-200'
                            }`}
                          >
                            {b.status}
                          </span>
                          <span className="text-xs text-gray-400">
                            {new Date(b.createdAt).toLocaleDateString()}
                          </span>
                        </div>

                        <div className="text-base font-bold text-gray-900">
                          {b.customerName}
                          <a
                            href={`tel:${b.customerPhone}`}
                            className="ml-2 font-mono text-xs text-amber-700 hover:underline font-bold"
                          >
                            📞 {b.customerPhone}
                          </a>
                        </div>

                        <div className="text-xs text-gray-600 flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-gray-800">{b.serviceName}</span>
                          <span className="text-gray-300">•</span>
                          <span>{b.tripType}</span>
                          <span className="text-gray-300">•</span>
                          <span>मिति: {b.pickupDate} ({b.pickupTime})</span>
                        </div>

                        {b.pickupLocation && (
                          <div className="text-xs text-gray-500">
                            स्थान: {b.pickupLocation} ➔ {b.dropLocation}
                          </div>
                        )}

                        {b.specialRequests && (
                          <div className="text-xs text-amber-800 bg-amber-50/60 p-1.5 rounded-md border border-amber-200/60">
                            टिप्पणी: {b.specialRequests}
                          </div>
                        )}
                      </div>

                      <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-3 sm:pt-0 border-gray-100 gap-2">
                        <div className="text-lg font-black text-amber-700 font-['Outfit']">
                          रु. {b.amount.toLocaleString('en-IN')}
                        </div>

                        <div className="flex items-center gap-1.5">
                          {b.status === 'pending' && (
                            <button
                              onClick={() => handleUpdateBookingStatus(b.id, 'confirmed')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                            >
                              पुष्टि गर्नुहोस्
                            </button>
                          )}
                          {b.status === 'confirmed' && (
                            <button
                              onClick={() => handleUpdateBookingStatus(b.id, 'completed')}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                            >
                              सम्पन्न भयो
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteBooking(b.id)}
                            className="p-1.5 rounded-lg bg-gray-100 hover:bg-red-50 text-gray-400 hover:text-red-600 transition-all cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: RATES MANAGEMENT */}
          {activeTab === 'rates' && (
            <div className="space-y-6 max-w-4xl mx-auto">
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
                <span className="font-bold">दररेट व्यवस्थापन:</span> यहाँ तय गरिएका भाडा दरहरू सम्पूर्ण वेबसाइट र बुकिङ क्यालकुलेटरमा तत्काल लागु हुनेछन्।
              </div>

              {rateSaveSuccess && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{rateSaveSuccess}</span>
                </div>
              )}

              <form onSubmit={handleSaveRates} className="space-y-6">
                {/* 1. Surkhet - Nepalgunj */}
                <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs space-y-4">
                  <h4 className="font-bold text-gray-900 text-sm flex items-center gap-2 font-['Outfit']">
                    <span>१. सुर्खेत ⇄ नेपालगन्ज (Surkhet to Nepalgunj)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        One Way (एकतर्फी भाडा - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.nepalgunjOneWay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, nepalgunjOneWay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        Two Way (दोहोरो भाडा - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.nepalgunjTwoWay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, nepalgunjTwoWay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* 2. Surkhet - Dailekh */}
                <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs space-y-4">
                  <h4 className="font-bold text-gray-900 text-sm flex items-center gap-2 font-['Outfit']">
                    <span>२. सुर्खेत ⇄ दैलेख (Surkhet to Dailekh)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        One Way (एकतर्फी भाडा - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.dailekhOneWay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, dailekhOneWay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        Two Way (दोहोरो भाडा - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.dailekhTwoWay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, dailekhTwoWay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* 3. Surkhet - Dhargadhi */}
                <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs space-y-4">
                  <h4 className="font-bold text-gray-900 text-sm flex items-center gap-2 font-['Outfit']">
                    <span>३. सुर्खेत ⇄ धनगढी (Surkhet to Dhargadhi)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        One Way (एकतर्फी भाडा - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.dhargadhiOneWay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, dhargadhiOneWay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        Two Way (दोहोरो भाडा - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.dhargadhiTwoWay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, dhargadhiTwoWay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* 4, 5, 6: Daily & Airport Rates */}
                <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs space-y-4">
                  <h4 className="font-bold text-gray-900 text-sm flex items-center gap-2 font-['Outfit']">
                    <span>४. दैनिक भ्रमण, विवाह तथा एयरपोर्ट ट्रान्सफर</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        उपत्यका भ्रमण (प्रति दिन - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.valleyTourPerDay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, valleyTourPerDay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        वैवाहिक रिजर्भ (प्रति दिन - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.weddingReservePerDay}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, weddingReservePerDay: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        एयरपोर्ट पिकअप/ड्रप (फिक्स - रु)
                      </label>
                      <input
                        type="number"
                        value={editingRates.airportPickupDrop}
                        onChange={(e) =>
                          setEditingRates({ ...editingRates, airportPickupDrop: Number(e.target.value) })
                        }
                        className="w-full py-2.5 px-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-sm font-bold focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3">
                  <button
                    type="button"
                    onClick={handleResetRates}
                    className="px-4 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold transition-all cursor-pointer"
                  >
                    सुरुवाती दर रिसेट (Reset Defaults)
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs sm:text-sm font-extrabold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>दररेट सुरक्षित गर्नुहोस् (Save Rates)</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: GALLERY (BYD ATTO 2 ONLY) */}
          {activeTab === 'gallery' && (
            <div className="space-y-6">
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
                <span className="font-bold">BYD ATTO 2 विशिष्ट ग्यालरी:</span> वेबसाइटमा केवल <strong>BYD ATTO 2</strong> गाडीका तस्बिरहरू मात्र राख्न अनुमति छ।
              </div>

              {gallerySuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{gallerySuccess}</span>
                </div>
              )}

              {/* Add Photo Form */}
              <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs">
                <h4 className="font-bold text-gray-900 text-sm mb-4 font-['Outfit']">
                  नयाँ BYD ATTO 2 फोटो थप्नुहोस् (Add BYD ATTO 2 Photo)
                </h4>
                <form onSubmit={handleAddGalleryPhoto} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">तस्बिर शीर्षक (Title) *</label>
                      <input
                        type="text"
                        placeholder="उदा: BYD ATTO 2 Sunset Shot"
                        value={newPhotoTitle}
                        onChange={(e) => setNewPhotoTitle(e.target.value)}
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">क्याटागोरी (Category)</label>
                      <select
                        value={newPhotoCategory}
                        onChange={(e) => setNewPhotoCategory(e.target.value as any)}
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white cursor-pointer"
                      >
                        <option value="exterior">Exterior (बाहिरी रूप)</option>
                        <option value="interior">Interior (भित्री क्याबिन)</option>
                        <option value="feature">Feature (सुविधा)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">फोटो URL *</label>
                      <input
                        type="text"
                        placeholder="https://... वा /src/assets/..."
                        value={newPhotoUrl}
                        onChange={(e) => setNewPhotoUrl(e.target.value)}
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 block mb-1">विवरण / क्याप्सन (Caption)</label>
                    <input
                      type="text"
                      placeholder="उदा: BYD ATTO 2 Electric SUV in Surkhet Valley"
                      value={newPhotoCaption}
                      onChange={(e) => setNewPhotoCaption(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>ग्यालरीमा थप्नुहोस् (Add to Gallery)</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Gallery Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {gallery.map((photo) => (
                  <div
                    key={photo.id}
                    className="p-3 rounded-2xl bg-white border border-gray-200 shadow-xs flex flex-col justify-between group"
                  >
                    <div>
                      <div className="h-36 rounded-xl overflow-hidden relative bg-gray-100 mb-2">
                        <BydImage
                          src={photo.imageUrl}
                          alt={photo.title}
                          className="w-full h-full object-cover"
                          showBadge={false}
                        />
                        <span className="absolute top-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded bg-black/60 text-white">
                          BYD ATTO 2
                        </span>
                      </div>
                      <h5 className="font-bold text-gray-900 text-xs line-clamp-1">{photo.title}</h5>
                      <p className="text-[11px] text-gray-500 line-clamp-2 mt-0.5">{photo.caption}</p>
                    </div>

                    <div className="pt-2 mt-2 border-t border-gray-100 flex items-center justify-between text-[10px] text-gray-400">
                      <span className="capitalize">{photo.category}</span>
                      <button
                        onClick={() => handleDeletePhoto(photo.id)}
                        className="text-red-500 hover:text-red-700 p-1 cursor-pointer"
                        title="Delete photo"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: SETTINGS & PASSWORD */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-4xl mx-auto">
              {/* Business Info */}
              <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs space-y-4">
                <h4 className="font-bold text-gray-900 text-sm font-['Outfit']">
                  व्यावसायिक सम्पर्क विवरणहरू (Business Settings)
                </h4>

                {settingsSuccess && (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{settingsSuccess}</span>
                  </div>
                )}

                <form onSubmit={handleSaveSettings} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">संस्थाको नाम (नेपाली)</label>
                      <input
                        type="text"
                        value={businessSettings.businessNameNepali}
                        onChange={(e) =>
                          setBusinessSettings({ ...businessSettings, businessNameNepali: e.target.value })
                        }
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">Business Name (English)</label>
                      <input
                        type="text"
                        value={businessSettings.businessNameEnglish}
                        onChange={(e) =>
                          setBusinessSettings({ ...businessSettings, businessNameEnglish: e.target.value })
                        }
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-gray-600 block mb-1">फोन नम्बर (Primary Phone) *</label>
                      <input
                        type="text"
                        value={businessSettings.phone}
                        onChange={(e) =>
                          setBusinessSettings({ ...businessSettings, phone: e.target.value })
                        }
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-gray-600 block mb-1">ह्वाट्सएप नम्बर (WhatsApp)</label>
                      <input
                        type="text"
                        value={businessSettings.whatsapp}
                        onChange={(e) =>
                          setBusinessSettings({ ...businessSettings, whatsapp: e.target.value })
                        }
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="text-xs text-gray-600 block mb-1">ठेगाना (Location)</label>
                      <input
                        type="text"
                        value={businessSettings.address}
                        onChange={(e) =>
                          setBusinessSettings({ ...businessSettings, address: e.target.value })
                        }
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-gray-600 block mb-1">TikTok Link</label>
                      <input
                        type="text"
                        value={businessSettings.tiktokUrl}
                        onChange={(e) =>
                          setBusinessSettings({ ...businessSettings, tiktokUrl: e.target.value })
                        }
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-gray-600 block mb-1">Facebook Link</label>
                      <input
                        type="text"
                        value={businessSettings.facebookUrl}
                        onChange={(e) =>
                          setBusinessSettings({ ...businessSettings, facebookUrl: e.target.value })
                        }
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      सम्पर्क विवरण सुरक्षित गर्नुहोस्
                    </button>
                  </div>
                </form>
              </div>

              {/* Password Management */}
              <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs space-y-4">
                <h4 className="font-bold text-gray-900 text-sm font-['Outfit'] flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-amber-600" />
                  <span>एडमिन पासवर्ड परिवर्तन (Change Admin Password)</span>
                </h4>

                {passwordSuccess && (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{passwordSuccess}</span>
                  </div>
                )}

                <form onSubmit={handleUpdatePassword} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">हालको पासवर्ड (Current) *</label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">नयाँ पासवर्ड (New) *</label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-600 block mb-1">नयाँ पासवर्ड पुनः (Confirm) *</label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full py-2 px-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 text-xs focus:outline-none focus:border-amber-500 focus:bg-white"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      पासवर्ड परिवर्तन गर्नुहोस् (Update Password)
                    </button>
                  </div>
                </form>
              </div>

              {/* Supabase Backend Database Card */}
              <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
                      <Database className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 text-sm font-['Outfit'] flex items-center gap-2">
                        <span>Supabase Backend Database</span>
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          सक्रिय (Active)
                        </span>
                      </h4>
                      <p className="text-xs text-gray-500 mt-0.5">
                        सबै अनलाइन बुकिङ तथा अपोइन्टमेन्टहरू Supabase क्लाउड डेटाबेसमा स्वचालित रूपमा सेभ हुन्छन्।
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={checkSupabase}
                      disabled={isCheckingSupabase}
                      className="px-3 py-1.5 rounded-xl border border-gray-200 hover:bg-gray-50 text-gray-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isCheckingSupabase ? 'animate-spin' : ''}`} />
                      <span>{isCheckingSupabase ? 'जाँच गर्दै...' : 'कनेक्सन जाँच'}</span>
                    </button>

                    <button
                      onClick={handleSyncToSupabase}
                      disabled={isSyncing}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer disabled:opacity-50"
                    >
                      <Database className="w-3.5 h-3.5" />
                      <span>{isSyncing ? 'सिंक हुँदै...' : 'डेटाबेसमा सिंक गर्नुहोस्'}</span>
                    </button>
                  </div>
                </div>

                {syncMessage && (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{syncMessage}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                    <span className="text-gray-500 block text-[11px]">Project ID:</span>
                    <span className="font-mono font-bold text-gray-900 text-xs select-all">
                      {SUPABASE_PROJECT_ID}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                    <span className="text-gray-500 block text-[11px]">API Key Type:</span>
                    <span className="font-bold text-gray-900 text-xs">
                      Publishable Anon Key (sb_pub...)
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                    <span className="text-gray-500 block text-[11px]">Sync Mode:</span>
                    <span className="font-bold text-emerald-700 text-xs">
                      Dual Sync (Client & Server)
                    </span>
                  </div>
                </div>

                {/* SQL Schema helper box */}
                <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 text-xs space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-900 flex items-center gap-1.5">
                      <span>Supabase SQL Setup (Table & Row-Level Security Rules)</span>
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={copySqlToClipboard}
                        className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                      >
                        {copiedSql ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>कपी भयो! (Copied)</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy SQL Script</span>
                          </>
                        )}
                      </button>

                      <a
                        href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql`}
                        target="_blank"
                        rel="noreferrer"
                        className="px-2.5 py-1 rounded-lg border border-amber-300 bg-white hover:bg-amber-100 text-amber-800 font-bold text-[11px] flex items-center gap-1 transition-colors"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>Open SQL Editor</span>
                      </a>
                    </div>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed">
                    यदि तपाईंको Supabase प्रोजेक्टमा <code>bookings</code> वा <code>appointments</code> टेबल पहिल्यै बनिसकेको छैन भने, माथिको <strong>Copy SQL Script</strong> बटन थिचेर Supabase SQL Editor मा १ क्लिकमै Run गर्नुहोस्।
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
