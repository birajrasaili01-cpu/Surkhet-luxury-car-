import React from 'react';
import { Phone, Calendar, ArrowRight, ShieldCheck, Zap, Sparkles, MapPin } from 'lucide-react';
import { BusinessSettings } from '../types/index.ts';
import { BYD_ATTO_2_IMAGES } from '../constants/images.ts';
import { BydImage } from './BydImage.tsx';

interface HeroProps {
  settings?: BusinessSettings;
  onOpenBooking: () => void;
  onExploreRates: () => void;
}

export const Hero: React.FC<HeroProps> = ({ settings, onOpenBooking, onExploreRates }) => {
  const phone = settings?.phone || '9802581402';

  return (
    <section id="hero" className="relative bg-gradient-to-b from-white via-gray-50/60 to-white py-12 sm:py-18 lg:py-22 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-6 space-y-6 text-left">
            {/* Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>कर्णाली प्रदेशको प्रिमियम EV सेवा</span>
              <span className="text-gray-300">•</span>
              <span className="text-gray-600 font-medium">वीरेन्द्रनगर, सुर्खेत</span>
            </div>

            {/* Main Headline promoting BYD ATTO 2 */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 tracking-tight font-['Outfit'] leading-[1.15]">
              सुर्खेतमा प्रिमियम <span className="text-amber-600">BYD ATTO 2</span> लक्जरी कार रिजर्भ
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-gray-600 leading-relaxed">
              १००% शुद्ध विद्युतीय (Zero Emission), पूर्ण वातानुकूलित (A/C) र अत्यन्त आरामदायी यात्रा।
              नेपालगन्ज, दैलेख, धनगढी, उपत्यका भ्रमण, वैवाहिक कार्यक्रम तथा सुर्खेत विमानस्थलका लागि पारदर्शी र निश्चित भाडा दर।
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-sm sm:text-base tracking-wide shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <Calendar className="w-4 h-4" />
                <span>कार रिजर्भ गर्नुहोस्</span>
              </button>

              <a
                href={`tel:${phone.replace(/[^0-9]/g, '')}`}
                className="px-6 py-3.5 rounded-xl border-2 border-amber-400/80 hover:border-amber-500 bg-amber-50/70 hover:bg-amber-100 text-gray-900 font-black text-sm sm:text-base transition-all flex items-center justify-center gap-2.5 shadow-xs hover:shadow-md group active:scale-95"
                title={`सिधा सम्पर्क कल: ${phone}`}
              >
                <div className="w-6 h-6 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Phone className="w-3.5 h-3.5 fill-current" />
                </div>
                <span>सम्पर्क: <strong className="font-['Outfit'] tracking-wider text-amber-900">{phone}</strong></span>
              </a>
            </div>

            {/* Trust Badges */}
            <div className="pt-6 border-t border-gray-200 grid grid-cols-3 gap-3">
              <div>
                <div className="text-xl sm:text-2xl font-black text-gray-900 font-['Outfit']">
                  BYD ATTO 2
                </div>
                <div className="text-xs text-gray-500 font-medium mt-0.5">
                  आधिकारिक मोडल
                </div>
              </div>

              <div>
                <div className="text-xl sm:text-2xl font-black text-amber-600 font-['Outfit']">
                  रु. १,०००
                </div>
                <div className="text-xs text-gray-500 font-medium mt-0.5">
                  विमानस्थल फिक्स दर
                </div>
              </div>

              <div>
                <div className="text-xl sm:text-2xl font-black text-gray-900 font-['Outfit']">
                  २४/७
                </div>
                <div className="text-xs text-gray-500 font-medium mt-0.5">
                  अन-कल बुकिङ
                </div>
              </div>
            </div>
          </div>

          {/* Right Image Column - Only BYD ATTO 2 */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-3xl overflow-hidden border border-gray-200 shadow-md bg-white p-2">
              <div className="rounded-2xl overflow-hidden relative">
                <BydImage
                  src={BYD_ATTO_2_IMAGES.hero}
                  alt="BYD ATTO 2 Luxury Car Reserve Sewa Surkhet"
                  className="w-full h-[320px] sm:h-[420px] object-cover"
                  showBadge={true}
                />

                {/* Subdued overlay tag */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-white/95 backdrop-blur-md border border-gray-200 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-gray-900 font-['Outfit']">
                        BYD ATTO 2 Luxury EV
                      </div>
                      <div className="text-xs text-gray-500">
                        शान्त, सुरक्षित र आरामदायी यात्रा
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={onExploreRates}
                    className="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
                  >
                    <span>दररेट हेर्नुहोस्</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
