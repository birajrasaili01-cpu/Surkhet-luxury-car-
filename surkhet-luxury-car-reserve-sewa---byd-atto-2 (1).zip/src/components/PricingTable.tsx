import React from 'react';
import { ServiceRates } from '../types/index.ts';
import { ShieldCheck, ArrowRight, Zap, Info } from 'lucide-react';

interface PricingTableProps {
  rates: ServiceRates;
  onBookRoute: (serviceId: string, plan?: 'one-way' | 'two-way') => void;
}

export const PricingTable: React.FC<PricingTableProps> = ({ rates, onBookRoute }) => {
  return (
    <section id="pricing" className="py-16 sm:py-22 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            १००% निश्चित र पारदर्शी
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 tracking-tight font-['Outfit']">
            आधिकारिक <span className="text-amber-600">दररेट तालिका</span>
          </h2>
          <p className="mt-3 text-gray-600 text-base sm:text-lg">
            सबै सेवाहरूको वास्तविक भाडा दर। कुनै हिडेन चार्ज वा मध्यस्थकर्ता बिना।
          </p>
        </div>

        {/* Pricing Table Card */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden max-w-5xl mx-auto">
          <div className="p-4 sm:p-5 bg-gray-50 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-600" />
              <span className="font-bold text-gray-900 text-sm sm:text-base font-['Outfit']">
                BYD ATTO 2 Standard Rates (सुर्खेत सेवा)
              </span>
            </div>
            <div className="text-xs text-gray-500 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-amber-600 shrink-0" />
              <span>A/C क्याबिन, अनुभवी चालक, इन्धन र सबै कर सहित</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50/50 text-xs font-bold text-gray-600 uppercase tracking-wider">
                  <th className="py-4 px-6">रुट / सेवा विवरण</th>
                  <th className="py-4 px-4 text-center">One Way (एकतर्फी)</th>
                  <th className="py-4 px-4 text-center">Two Way (दोहोरो)</th>
                  <th className="py-4 px-4 text-center">गाडी</th>
                  <th className="py-4 px-6 text-right">कार्य</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-sm">
                {/* 1. Nepalgunj */}
                <tr className="hover:bg-amber-50/30 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-bold text-gray-900 text-base">सुर्खेत ⇄ नेपालगन्ज</div>
                    <div className="text-xs text-gray-500">Surkhet to Nepalgunj</div>
                  </td>
                  <td className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.nepalgunjOneWay.toLocaleString('en-IN')}
                  </td>
                  <td className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.nepalgunjTwoWay.toLocaleString('en-IN')}
                  </td>
                  <td className="py-4 px-4 text-center text-xs text-gray-500">
                    <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 font-medium">BYD ATTO 2</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => onBookRoute('surkhet-nepalgunj', 'one-way')}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      रिजर्भ बुक
                    </button>
                  </td>
                </tr>

                {/* 2. Dailekh */}
                <tr className="hover:bg-amber-50/30 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-bold text-gray-900 text-base">सुर्खेत ⇄ दैलेख</div>
                    <div className="text-xs text-gray-500">Surkhet to Dailekh</div>
                  </td>
                  <td className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.dailekhOneWay.toLocaleString('en-IN')}
                  </td>
                  <td className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.dailekhTwoWay.toLocaleString('en-IN')}
                  </td>
                  <td className="py-4 px-4 text-center text-xs text-gray-500">
                    <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 font-medium">BYD ATTO 2</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => onBookRoute('surkhet-dailekh', 'one-way')}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      रिजर्भ बुक
                    </button>
                  </td>
                </tr>

                {/* 3. Dhargadhi */}
                <tr className="hover:bg-amber-50/30 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-bold text-gray-900 text-base">सुर्खेत ⇄ धनगढी (Dhargadhi)</div>
                    <div className="text-xs text-gray-500">Surkhet to Dhargadhi</div>
                  </td>
                  <td className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.dhargadhiOneWay.toLocaleString('en-IN')}
                  </td>
                  <td className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.dhargadhiTwoWay.toLocaleString('en-IN')}
                  </td>
                  <td className="py-4 px-4 text-center text-xs text-gray-500">
                    <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 font-medium">BYD ATTO 2</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => onBookRoute('surkhet-dhargadhi', 'one-way')}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      रिजर्भ बुक
                    </button>
                  </td>
                </tr>

                {/* 4. Valley Tour */}
                <tr className="hover:bg-amber-50/30 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-bold text-gray-900 text-base">सुर्खेत उपत्यका भ्रमण (Valley Tour)</div>
                    <div className="text-xs text-gray-500">काँक्रेविहार, बुलबुले, देउती बज्यै, घण्टाघर</div>
                  </td>
                  <td colSpan={2} className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.valleyTourPerDay.toLocaleString('en-IN')} / दिन (Per Day)
                  </td>
                  <td className="py-4 px-4 text-center text-xs text-gray-500">
                    <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 font-medium">BYD ATTO 2</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => onBookRoute('valley-tour')}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      दिन छान्नुहोस्
                    </button>
                  </td>
                </tr>

                {/* 5. Wedding */}
                <tr className="hover:bg-amber-50/30 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-bold text-gray-900 text-base">वैवाहिक लक्जरी कार रिजर्भ</div>
                    <div className="text-xs text-gray-500">Wedding Reserve (विवाह विशेष)</div>
                  </td>
                  <td colSpan={2} className="py-4 px-4 text-center font-bold text-amber-700 font-['Outfit'] text-base">
                    रु. {rates.weddingReservePerDay.toLocaleString('en-IN')} / दिन (Per Day)
                  </td>
                  <td className="py-4 px-4 text-center text-xs text-gray-500">
                    <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 font-medium">BYD ATTO 2</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => onBookRoute('wedding-reserve')}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      विवाह बुक
                    </button>
                  </td>
                </tr>

                {/* 6. Airport */}
                <tr className="bg-amber-50/60 hover:bg-amber-100/40 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-bold text-amber-900 text-base flex items-center gap-2">
                      <span>सुर्खेत विमानस्थल पिकअप र ड्रप</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500 text-white font-extrabold uppercase">
                        Fixed Rate
                      </span>
                    </div>
                    <div className="text-xs text-gray-600">Surkhet Airport (SKH) ⇄ होटेल / घर</div>
                  </td>
                  <td colSpan={2} className="py-4 px-4 text-center font-black text-amber-700 font-['Outfit'] text-lg">
                    कुल रकम: रु. {rates.airportPickupDrop.toLocaleString('en-IN')} मात्र
                  </td>
                  <td className="py-4 px-4 text-center text-xs text-gray-500">
                    <span className="px-2 py-0.5 rounded bg-white text-gray-800 font-semibold border border-gray-200">BYD ATTO 2</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => onBookRoute('airport-pickup-drop')}
                      className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-extrabold transition-all shadow-xs cursor-pointer"
                    >
                      एयरपोर्ट बुक
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};
