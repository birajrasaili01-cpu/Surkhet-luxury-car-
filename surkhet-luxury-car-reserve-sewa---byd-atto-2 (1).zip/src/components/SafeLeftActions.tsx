import React, { useState } from 'react';
import { Phone, Calendar, MessageCircle, X, ChevronRight, CheckCircle2, Sparkles } from 'lucide-react';

interface SafeLeftActionsProps {
  phone: string;
  onBookNow: () => void;
}

export const SafeLeftActions: React.FC<SafeLeftActionsProps> = ({
  phone = '9802581402',
  onBookNow,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const cleanPhone = phone.replace(/[^0-9]/g, '');

  return (
    <aside
      aria-label="सम्पर्क तथा बुकिङ सुविधा"
      className="fixed left-3 sm:left-6 bottom-22 sm:bottom-7 z-40 transition-all duration-300"
      style={{
        left: 'max(0.75rem, env(safe-area-inset-left, 0.75rem))',
      }}
    >
      {!isMinimized ? (
        <div className="bg-white/98 backdrop-blur-md border border-gray-200/90 shadow-2xl rounded-2xl p-3 sm:p-3.5 flex flex-col gap-2.5 w-[275px] sm:w-[290px] animate-in fade-in slide-in-from-left-4 duration-200 ring-1 ring-black/5">
          {/* Top Status Bar with Minimize Action */}
          <div className="flex items-center justify-between border-b border-gray-100 pb-2">
            <div className="flex items-center gap-1.5">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span className="text-[11px] font-bold text-gray-800 tracking-tight">
                २४/७ अन-कल सेवा उपलब्ध
              </span>
            </div>
            <button
              onClick={() => setIsMinimized(true)}
              className="text-gray-400 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
              title="प्यानल सानो बनाउनुहोस्"
              aria-label="Minimize"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* 1. ULTRA HIGH-QUALITY CLEAR CONTACT BUTTON */}
          <a
            href={`tel:${cleanPhone}`}
            className="relative flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold shadow-md hover:shadow-lg transition-all duration-200 group active:scale-[0.98] border border-amber-400/40"
            title={`सिधा सम्पर्क कल: ${phone}`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/30 text-white shadow-xs group-hover:rotate-12 transition-transform">
                <Phone className="w-5 h-5 fill-current" />
              </div>
              <div className="flex flex-col text-left leading-tight">
                <span className="text-[10px] uppercase font-bold text-amber-100 tracking-wider">
                  सिधा सम्पर्क (Call Direct)
                </span>
                <span className="text-base sm:text-lg font-black text-white font-['Outfit'] tracking-wider">
                  {phone}
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-amber-200 group-hover:translate-x-0.5 transition-transform" />
          </a>

          {/* 2. HIGH-QUALITY BOOKING BUTTON */}
          <button
            onClick={onBookNow}
            className="flex items-center justify-center gap-2 w-full py-2.5 px-3 rounded-xl bg-gray-900 hover:bg-black text-white font-extrabold text-xs sm:text-sm tracking-wide shadow-xs hover:shadow-md transition-all cursor-pointer active:scale-[0.98] border border-gray-800"
          >
            <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
            <span>कार रिजर्भ गर्नुहोस् (Book Now)</span>
          </button>

          {/* 3. HIGH-QUALITY WHATSAPP CONTACT BUTTON */}
          <a
            href={`https://wa.me/977${cleanPhone}?text=${encodeURIComponent(
              'नमस्ते, म सुर्खेत लक्जरी कार रिजर्भ Sewa को BYD ATTO 2 बुक गर्न चाहन्छु।'
            )}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-800 font-bold text-xs transition-colors"
          >
            <MessageCircle className="w-4 h-4 text-emerald-600 fill-emerald-600" />
            <span>ह्वाट्सएपमा च्याट गर्नुहोस्</span>
          </a>

          {/* Subtitle info */}
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-gray-500 pt-0.5">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>SURKHET LUXURY CAR RESERVE SEWA</span>
          </div>
        </div>
      ) : (
        /* MINIMIZED ULTRA-CLEAR CONTACT & BOOKING BADGES */
        <div className="flex flex-col gap-2.5 animate-in fade-in zoom-in-95 duration-150">
          {/* Clear High-Quality Round Phone Button */}
          <a
            href={`tel:${cleanPhone}`}
            className="relative group w-13 h-13 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-xl flex items-center justify-center transition-all hover:scale-105 border-2 border-white ring-4 ring-amber-500/20 active:scale-95"
            title={`सिधा सम्पर्क: ${phone}`}
          >
            <Phone className="w-6 h-6 fill-current animate-bounce" />
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white"></span>
            
            {/* Tooltip on hover */}
            <span className="absolute left-15 bg-gray-900 text-white text-xs font-bold px-2.5 py-1.5 rounded-xl whitespace-nowrap shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              📞 कल: {phone}
            </span>
          </a>

          {/* Clear High-Quality Round Booking Button */}
          <button
            onClick={onBookNow}
            className="relative group w-13 h-13 rounded-2xl bg-gray-900 hover:bg-black text-amber-400 shadow-xl flex items-center justify-center transition-all hover:scale-105 border-2 border-white ring-4 ring-gray-900/10 active:scale-95 cursor-pointer"
            title="कार रिजर्भ गर्नुहोस्"
          >
            <Calendar className="w-6 h-6" />
            <span className="absolute left-15 bg-gray-900 text-white text-xs font-bold px-2.5 py-1.5 rounded-xl whitespace-nowrap shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              📅 कार रिजर्भ गर्नुहोस्
            </span>
          </button>

          {/* Expand Pill */}
          <button
            onClick={() => setIsMinimized(false)}
            className="px-2 py-1 rounded-lg bg-white/95 text-gray-700 hover:text-gray-900 text-[10px] font-extrabold shadow-sm border border-gray-200 text-center cursor-pointer transition-colors"
          >
            सम्पर्क खोल्नुहोस्
          </button>
        </div>
      )}
    </aside>
  );
};
