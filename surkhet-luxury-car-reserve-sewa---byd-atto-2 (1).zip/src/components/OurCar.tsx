import React, { useState } from 'react';
import { BYD_ATTO_2_IMAGES } from '../constants/images.ts';
import { BydImage } from './BydImage.tsx';
import { ShieldCheck, BatteryCharging, Wind, Sparkles, Check, Compass, Gauge, Cpu } from 'lucide-react';

export const OurCar: React.FC = () => {
  const [activeView, setActiveView] = useState<'front' | 'interior' | 'rear'>('front');

  const views = [
    {
      id: 'front' as const,
      label: 'बाहिरी रूप (Exterior Front)',
      img: BYD_ATTO_2_IMAGES.front,
      desc: 'एरोडाइनामिक सिल्हूट, स्लीक क्रिस्टल एलईडी हेडलाइट्स, र आधुनिक ईभी ग्रिल',
    },
    {
      id: 'interior' as const,
      label: 'भित्री लक्जरी (Luxury Interior)',
      img: BYD_ATTO_2_IMAGES.interior,
      desc: 'पूर्ण वातानुकूलित (A/C) क्याबिन, रोटेटिङ टचस्क्रिन, र आरामदायी अर्गोनोमिक सिटहरू',
    },
    {
      id: 'rear' as const,
      label: 'पछाडिको डिजाइन (Rear & Boot)',
      img: BYD_ATTO_2_IMAGES.rear,
      desc: 'निरन्तर एलईडी टेललाइट बार, सुरक्षित ग्राउन्ड क्लियरेन्स र प्रशस्त लगेज स्पेस',
    },
  ];

  const currentView = views.find((v) => v.id === activeView) || views[0];

  const specs = [
    { label: 'गाडीको मोडल', value: 'BYD ATTO 2 (२०२४/२०२५)' },
    { label: 'प्रविधि', value: '१००% शुद्ध विद्युतीय (EV)' },
    { label: 'ब्याट्री', value: 'अल्ट्रा-सेफ BYD Blade Battery' },
    { label: 'वातानुकूलित', value: 'Dual Zone A/C क्लाइमेट' },
    { label: 'सिट क्षमता', value: '४ जना यात्रु + १ अनुभवी चालक' },
    { label: 'सडक सुरक्षा', value: 'कर्णालीका पहाडी सडक अनुकूल' },
  ];

  return (
    <section id="our-car" className="py-16 sm:py-22 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider mb-3">
            हाम्रो आधिकारिक गाडी
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 tracking-tight font-['Outfit']">
            Our Premium Fleet: <span className="text-amber-600">BYD ATTO 2</span>
          </h2>
          <p className="mt-3 text-gray-600 text-base sm:text-lg">
            हाम्रो सुर्खेत लक्जरी कार रिजर्भ सेवामा केवल वास्तविक <strong>BYD ATTO 2</strong> प्रयोग गरिन्छ।
            कुनै अन्य साधारण गाडी वा सम्झौता बिनाको प्रिमियम यात्रा।
          </p>

          {/* View Toggles */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {views.map((v) => (
              <button
                key={v.id}
                onClick={() => setActiveView(v.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeView === v.id
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200'
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>
        </div>

        {/* Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Main Visual Display */}
          <div className="lg:col-span-7">
            <div className="rounded-3xl border border-gray-200 bg-gray-50 p-3 sm:p-4 shadow-sm">
              <div className="rounded-2xl overflow-hidden relative bg-white border border-gray-100">
                <BydImage
                  src={currentView.img}
                  alt={`BYD ATTO 2 ${currentView.label} Surkhet`}
                  className="w-full h-[320px] sm:h-[440px] object-cover"
                  showBadge={true}
                />
              </div>
              <div className="mt-4 px-2 flex items-center justify-between text-xs sm:text-sm text-gray-600">
                <span className="font-semibold text-gray-800">{currentView.desc}</span>
                <span className="text-amber-700 font-bold shrink-0 ml-2">BYD ATTO 2 Only</span>
              </div>
            </div>
          </div>

          {/* Specs & Highlights */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] mb-4 flex items-center gap-2">
                <Cpu className="w-5 h-5 text-amber-600" />
                <span>BYD ATTO 2 प्राविधिक विशेषताहरू</span>
              </h3>

              <div className="divide-y divide-gray-200">
                {specs.map((item, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between text-xs sm:text-sm">
                    <span className="text-gray-500 font-medium">{item.label}</span>
                    <span className="font-bold text-gray-900 text-right">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Comfort checklist */}
            <div className="space-y-2.5">
              {[
                'शान्त र कम्पनरहित १००% इलेक्ट्रिक यात्रा',
                'उच्च सुरक्षा (५-स्टार स्तरको ब्याट्री तथा संरचना)',
                'कर्णाली र सुर्खेतका सडकहरूमा अत्यन्त स्मूथ राइड',
                'विवाह तथा विशिष्ट पाहुनाहरूका लागि उत्कृष्ट सत्कार',
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-2.5 text-xs sm:text-sm text-gray-700">
                  <div className="w-5 h-5 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-200">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>{text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
