import React from 'react';
import { Award, CheckCircle } from 'lucide-react';
import { BydImage } from './BydImage.tsx';
import { BYD_ATTO_2_IMAGES } from '../constants/images.ts';

export const AboutSection: React.FC = () => {
  const highlights = [
    { title: '१००% विद्युतीय BYD ATTO 2', desc: 'नवीनतम प्रविधि, प्रदूषणरहित र सुरक्षित EV प्रविधि' },
    { title: 'प्रशिक्षित तथा शलीन चालक', desc: 'कर्णालीका सडकहरूमा लामो अनुभव भएका भरपर्दा सारथी' },
    { title: 'पारदर्शी एवं निश्चित भाडा', desc: 'कुनै हिडेन चार्ज बिना पहिल्यै तय गरिएको डिजिटल दररेट' },
    { title: '२४/७ चौबिसै घण्टा उपलब्धता', desc: 'आकस्मिक वा पूर्व-योजित यात्राका लागि सधैं तयार' },
  ];

  return (
    <section id="about" className="py-16 sm:py-22 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Image with BYD ATTO 2 badge */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden border border-gray-200 shadow-md bg-white p-2">
              <div className="rounded-2xl overflow-hidden relative">
                <BydImage
                  src={BYD_ATTO_2_IMAGES.interior}
                  alt="BYD ATTO 2 Luxury Cabin Surkhet"
                  className="w-full h-[340px] sm:h-[420px] object-cover"
                  showBadge={true}
                />
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-white/95 backdrop-blur-md border border-gray-200 shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-gray-900">कर्णालीको विश्वासिलो लक्जरी सेवा</div>
                      <div className="text-xs text-gray-600">SURKHET LUXURY CAR RESERVE SEWA</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: About content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider">
              हाम्रो बारेमा (About Us)
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 tracking-tight font-['Outfit']">
              सुर्खेतमा प्रिमियम कार यात्राको{' '}
              <span className="text-amber-600">नयाँ परिभाषा</span>
            </h2>

            <p className="text-gray-600 text-base sm:text-lg leading-relaxed">
              <strong>SURKHET LUXURY CAR RESERVE SEWA</strong> (सुर्खेत लक्जरी कार रिजर्भ सेवा) कर्णाली प्रदेशको
              मुटु <strong>वीरेन्द्रनगर, सुर्खेत</strong> मा आधारित अग्रणी विद्युतीय कार रिजर्भ सेवा हो। हामी केवल अत्याधुनिक{' '}
              <strong>BYD ATTO 2</strong> लक्जरी विद्युतीय SUV मार्फत विशिष्ट सेवा प्रदान गर्दछौं।
            </p>

            <p className="text-gray-500 text-sm sm:text-base leading-relaxed">
              चाहे तपाईंलाई नेपालगन्ज, दैलेख वा धनगढी जानु परेको होस्, वा सुर्खेत उपत्यका भ्रमण, वैवाहिक कार्यक्रम,
              वा सुर्खेत विमानस्थलबाट सहज पिकअप र ड्रप चाहिएको होस् — हामी समयमै, सफा र पूर्ण वातानुकूलित क्याबिनसहित
              उपलब्ध छौं।
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {highlights.map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-gray-50 border border-gray-200 flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold text-gray-900">{item.title}</h4>
                    <p className="text-xs text-gray-500 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
