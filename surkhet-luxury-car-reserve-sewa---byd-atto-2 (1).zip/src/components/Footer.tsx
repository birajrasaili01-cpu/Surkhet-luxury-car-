import React, { useState, useEffect } from 'react';
import { Car, Zap, Phone, MapPin, Mail, Shield, UserPlus, Lock } from 'lucide-react';
import { BusinessSettings } from '../types/index.ts';
import { api } from '../services/api.ts';

interface FooterProps {
  settings?: BusinessSettings;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, onOpenAdmin }) => {
  const [isConfigured, setIsConfigured] = useState<boolean | null>(null);
  const phone = settings?.phone || '9802581402';
  const email = settings?.email || 'info@surkhetluxurycar.com';
  const address = settings?.address || 'वीरेन्द्रनगर, सुर्खेत';

  useEffect(() => {
    let isMounted = true;
    const checkStatus = async () => {
      try {
        const res = await api.getSetupStatus();
        if (isMounted && res.success) {
          setIsConfigured(!!res.isConfigured);
        }
      } catch (e) {
        // silent fallback
      }
    };
    checkStatus();
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <footer className="bg-gray-50 border-t border-gray-200 text-gray-600 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Col 1: Brand & Tagline */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                <Car className="w-5 h-5" />
              </div>
              <div>
                <span className="text-base font-extrabold text-gray-900 font-['Outfit'] block leading-none">
                  SURKHET LUXURY CAR
                </span>
                <span className="text-[11px] text-amber-700 font-bold">
                  RESERVE SEWA • BYD ATTO 2
                </span>
              </div>
            </div>

            <p className="text-xs text-gray-600 leading-relaxed">
              कर्णाली प्रदेशको राजधानी सुर्खेतमा १००% विद्युतीय BYD ATTO 2 लक्जरी कार रिजर्भ सेवा।
              नेपालगन्ज, दैलेख, धनगढी, उपत्यका भ्रमण तथा विमानस्थल स्थानान्तरण।
            </p>

            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-gray-200 text-xs text-gray-700">
              <Zap className="w-3.5 h-3.5 text-amber-600" />
              <span>१००% शुद्ध विद्युतीय (Zero Emission)</span>
            </div>
          </div>

          {/* Col 2: Routes & Services */}
          <div>
            <h4 className="text-gray-900 font-bold text-xs uppercase tracking-wider mb-4 font-['Outfit']">
              प्रमुख रुटहरू (Popular Routes)
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#services" className="hover:text-amber-700 transition-colors">
                  सुर्खेत ⇄ नेपालगन्ज (One Way: रु. ५,००० / Two Way: रु. ८,०००)
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-700 transition-colors">
                  सुर्खेत ⇄ दैलेख (One Way: रु. ६,००० / Two Way: रु. ८,०००)
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-700 transition-colors">
                  सुर्खेत ⇄ धनगढी (One Way: रु. १५,००० / Two Way: रु. १८,०००)
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-700 transition-colors">
                  सुर्खेत उपत्यका भ्रमण (रु. ५,००० प्रति दिन)
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-700 transition-colors">
                  विमानस्थल पिकअप र ड्रप (निश्चित रु. १,०००)
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Navigation */}
          <div>
            <h4 className="text-gray-900 font-bold text-xs uppercase tracking-wider mb-4 font-['Outfit']">
              छिटो लिङ्कहरू (Quick Links)
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#hero" className="hover:text-amber-700 transition-colors">गृहपृष्ठ (Home)</a>
              </li>
              <li>
                <a href="#our-car" className="hover:text-amber-700 transition-colors">हाम्रो BYD ATTO 2 (Our Car)</a>
              </li>
              <li>
                <a href="#why-choose-us" className="hover:text-amber-700 transition-colors">हामीलाई किन रोज्ने? (Why Us)</a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-700 transition-colors">सेवा तथा सुविधाहरू (Services)</a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-amber-700 transition-colors">दररेट तालिका (Pricing)</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-amber-700 transition-colors">फोटो ग्यालरी (Gallery)</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-amber-700 transition-colors">सम्पर्क (Contact)</a>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact & Dedicated Admin Portal Entry */}
          <div>
            <h4 className="text-gray-900 font-bold text-xs uppercase tracking-wider mb-4 font-['Outfit']">
              सम्पर्क र व्यवस्थापन
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <a href={`tel:${phone.replace(/[^0-9]/g, '')}`} className="font-bold text-gray-900 hover:text-amber-700">
                  {phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>{email}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>{address}</span>
              </div>
            </div>

            {/* Exclusive Footer Admin Link (Sign-up or Login based on Single Slot status) */}
            <div className="pt-4 mt-4 border-t border-gray-200">
              <button
                onClick={onOpenAdmin}
                className="w-full p-2.5 rounded-xl bg-white hover:bg-gray-100 text-gray-800 hover:text-amber-800 text-xs font-bold flex items-center justify-between border border-gray-200 hover:border-amber-400 cursor-pointer transition-all shadow-2xs group"
                title={isConfigured === false ? 'Create Admin Account (1 Slot Available)' : 'Admin Login Portal'}
              >
                <div className="flex items-center gap-2">
                  {isConfigured === false ? (
                    <UserPlus className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
                  ) : (
                    <Shield className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
                  )}
                  <span className="font-semibold">
                    {isConfigured === false ? 'एडमिन साइन-अप (Sign Up)' : 'एडमिन लगइन (Admin Login)'}
                  </span>
                </div>
                <span
                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                    isConfigured === false
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200 animate-pulse'
                      : 'bg-amber-100 text-amber-900 border border-amber-200'
                  }`}
                >
                  {isConfigured === false ? '१ स्लट खुला' : 'पोर्टल'}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom bar with Admin portal shortcut */}
        <div className="mt-12 pt-6 border-t border-gray-200 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500 gap-3">
          <div>
            © {new Date().getFullYear()} SURKHET LUXURY CAR RESERVE SEWA. All rights reserved.
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <span>सञ्चालित गाडी:</span>
              <span className="font-bold text-amber-700">BYD ATTO 2 Luxury EV</span>
            </div>
            <span className="text-gray-300">•</span>
            <button
              onClick={onOpenAdmin}
              className="text-gray-500 hover:text-amber-700 hover:underline transition-colors cursor-pointer font-medium"
            >
              {isConfigured === false ? 'व्यवस्थापक दर्ता (Sign Up)' : 'व्यवस्थापक लगइन (Admin Login)'}
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
