import React, { useState } from 'react';
import { GalleryPhoto } from '../types/index.ts';
import { BydImage } from './BydImage.tsx';
import { Sparkles, Maximize2, X, ShieldCheck } from 'lucide-react';

interface GallerySectionProps {
  photos: GalleryPhoto[];
}

export const GallerySection: React.FC<GallerySectionProps> = ({ photos }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [previewPhoto, setPreviewPhoto] = useState<GalleryPhoto | null>(null);

  // Guarantee BYD ATTO 2 photos only
  const bydPhotos = photos.filter((p) => p.isBydAtto2 !== false);

  const filteredPhotos =
    selectedCategory === 'all'
      ? bydPhotos
      : bydPhotos.filter((p) => p.category === selectedCategory);

  const categories = [
    { id: 'all', label: 'सबै फोटोहरू (All Photos)' },
    { id: 'exterior', label: 'बाहिरी रूप (Exterior)' },
    { id: 'interior', label: 'भित्री लक्जरी (Interior)' },
    { id: 'feature', label: 'सुविधाहरू (Features)' },
  ];

  return (
    <section id="gallery" className="py-16 sm:py-22 bg-gray-50/70 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            BYD ATTO 2 आधिकारिक फोटो ग्यालरी
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 tracking-tight font-['Outfit']">
            Exclusive <span className="text-amber-600">BYD ATTO 2</span> Showcase
          </h2>
          <p className="mt-3 text-gray-600 text-base sm:text-lg">
            हाम्रो सुर्खेत लक्जरी कार रिजर्भ सेवामा सञ्चालित १००% विद्युतीय <strong>BYD ATTO 2</strong> का वास्तविक तस्बिरहरू।
          </p>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'bg-white text-gray-700 border border-gray-200 hover:border-gray-300'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredPhotos.map((photo) => (
            <div
              key={photo.id}
              onClick={() => setPreviewPhoto(photo)}
              className="group relative rounded-2xl overflow-hidden border border-gray-200 hover:border-amber-400 bg-white shadow-xs hover:shadow-md cursor-pointer transition-all duration-200"
            >
              <div className="h-56 overflow-hidden relative bg-gray-100">
                <BydImage
                  src={photo.imageUrl}
                  alt={photo.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  showBadge={true}
                />
                <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="p-3 rounded-full bg-white text-gray-900 shadow-md">
                    <Maximize2 className="w-4 h-4 text-amber-600" />
                  </div>
                </div>
              </div>

              <div className="p-4 bg-white">
                <div className="flex items-center justify-between text-[11px] text-amber-700 font-bold mb-1">
                  <span className="uppercase tracking-wider font-['Outfit']">BYD ATTO 2</span>
                  <span className="capitalize text-gray-400 font-medium">{photo.category}</span>
                </div>
                <h4 className="font-bold text-gray-900 text-sm line-clamp-1 group-hover:text-amber-600 transition-colors">
                  {photo.title}
                </h4>
                <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                  {photo.caption}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {previewPhoto && (
        <div
          onClick={() => setPreviewPhoto(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-xs animate-in fade-in"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl w-full bg-white rounded-3xl overflow-hidden border border-gray-200 shadow-2xl"
          >
            <button
              onClick={() => setPreviewPhoto(null)}
              className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-black/60 hover:bg-black text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="max-h-[70vh] overflow-hidden bg-black flex items-center justify-center">
              <img
                src={previewPhoto.imageUrl}
                alt={previewPhoto.title}
                className="w-full max-h-[70vh] object-contain"
              />
            </div>

            <div className="p-5 sm:p-6 bg-white border-t border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                    BYD ATTO 2 Verified
                  </span>
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 font-['Outfit']">
                  {previewPhoto.title}
                </h3>
                <p className="text-xs sm:text-sm text-gray-600 mt-1">
                  {previewPhoto.caption}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
