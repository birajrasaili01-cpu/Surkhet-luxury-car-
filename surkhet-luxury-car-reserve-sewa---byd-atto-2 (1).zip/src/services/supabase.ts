import { createClient } from '@supabase/supabase-js';
import { BookingItem } from '../types/index.ts';

// Configured with user's Supabase project credentials
export const SUPABASE_PROJECT_ID = 'zfpbtzuqgqrnxjhzpbhr';
export const SUPABASE_URL =
  (typeof process !== 'undefined' && process.env?.SUPABASE_URL) ||
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) ||
  `https://${SUPABASE_PROJECT_ID}.supabase.co`;

export const SUPABASE_ANON_KEY =
  (typeof process !== 'undefined' && process.env?.SUPABASE_KEY) ||
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) ||
  'sb_publishable_Bm5ixTLYtGhcCFUfOYQPnw_puGA-0rJ';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export const SUPABASE_SETUP_SQL = `-- Run this in your Supabase SQL Editor:
-- https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql

-- 1. Create bookings table
CREATE TABLE IF NOT EXISTS public.bookings (
  id TEXT PRIMARY KEY,
  reference_id TEXT,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  service_id TEXT NOT NULL,
  service_name TEXT,
  trip_type TEXT,
  route_plan TEXT,
  number_of_days INTEGER,
  pickup_date TEXT NOT NULL,
  pickup_time TEXT,
  pickup_location TEXT NOT NULL,
  drop_location TEXT,
  passenger_count INTEGER DEFAULT 1,
  special_requests TEXT,
  amount NUMERIC,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create appointments table (alternate table name)
CREATE TABLE IF NOT EXISTS public.appointments (
  id TEXT PRIMARY KEY,
  reference_id TEXT,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  service_id TEXT NOT NULL,
  service_name TEXT,
  trip_type TEXT,
  route_plan TEXT,
  number_of_days INTEGER,
  pickup_date TEXT NOT NULL,
  pickup_time TEXT,
  pickup_location TEXT NOT NULL,
  drop_location TEXT,
  passenger_count INTEGER DEFAULT 1,
  special_requests TEXT,
  amount NUMERIC,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Enable Row Level Security (RLS)
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- 4. Allow public booking form submissions
DROP POLICY IF EXISTS "Allow public insert on bookings" ON public.bookings;
CREATE POLICY "Allow public insert on bookings" 
ON public.bookings FOR INSERT TO public WITH CHECK (true);

DROP POLICY IF EXISTS "Allow public read on bookings" ON public.bookings;
CREATE POLICY "Allow public read on bookings" 
ON public.bookings FOR SELECT TO public USING (true);

DROP POLICY IF EXISTS "Allow public insert on appointments" ON public.appointments;
CREATE POLICY "Allow public insert on appointments" 
ON public.appointments FOR INSERT TO public WITH CHECK (true);

DROP POLICY IF EXISTS "Allow public read on appointments" ON public.appointments;
CREATE POLICY "Allow public read on appointments" 
ON public.appointments FOR SELECT TO public USING (true);
`;

/**
 * Saves a booking into the Supabase database.
 * Supports multiple table targets (bookings, appointments) and handles both
 * snake_case and camelCase schema definitions gracefully.
 */
export async function saveBookingToSupabase(booking: BookingItem): Promise<{
  success: boolean;
  tableUsed?: string;
  error?: string;
  data?: any;
}> {
  // Format data payload for Supabase
  const snakeCasePayload = {
    id: booking.id,
    reference_id: booking.referenceId,
    customer_name: booking.customerName,
    customer_phone: booking.customerPhone,
    customer_email: booking.customerEmail || null,
    service_id: booking.serviceId,
    service_name: booking.serviceName,
    trip_type: booking.tripType || null,
    route_plan: booking.routePlan || null,
    number_of_days: booking.numberOfDays ? Number(booking.numberOfDays) : null,
    pickup_date: booking.pickupDate,
    pickup_time: booking.pickupTime || null,
    pickup_location: booking.pickupLocation,
    drop_location: booking.dropLocation || null,
    passenger_count: booking.passengerCount || 1,
    special_requests: booking.specialRequests || null,
    amount: booking.amount,
    status: booking.status || 'pending',
    created_at: booking.createdAt || new Date().toISOString(),
  };

  const camelCasePayload = {
    id: booking.id,
    referenceId: booking.referenceId,
    customerName: booking.customerName,
    customerPhone: booking.customerPhone,
    customerEmail: booking.customerEmail || null,
    serviceId: booking.serviceId,
    serviceName: booking.serviceName,
    tripType: booking.tripType || null,
    routePlan: booking.routePlan || null,
    numberOfDays: booking.numberOfDays ? Number(booking.numberOfDays) : null,
    pickupDate: booking.pickupDate,
    pickupTime: booking.pickupTime || null,
    pickupLocation: booking.pickupLocation,
    dropLocation: booking.dropLocation || null,
    passengerCount: booking.passengerCount || 1,
    specialRequests: booking.specialRequests || null,
    amount: booking.amount,
    status: booking.status || 'pending',
    createdAt: booking.createdAt || new Date().toISOString(),
  };

  // Attempt insertions in order of common table names
  const candidateTables = ['bookings', 'appointments', 'car_bookings'];
  let lastError: any = null;

  for (const tableName of candidateTables) {
    try {
      // 1. Try standard snake_case schema
      const { data, error } = await supabase
        .from(tableName)
        .insert([snakeCasePayload])
        .select();

      if (!error) {
        console.log(`[Supabase] Booking saved successfully to table '${tableName}':`, booking.referenceId);
        return { success: true, tableUsed: tableName, data };
      }

      // If schema column mismatch, try camelCase schema
      if (error.code !== 'PGRST205') {
        const { data: camelData, error: camelError } = await supabase
          .from(tableName)
          .insert([camelCasePayload])
          .select();

        if (!camelError) {
          console.log(`[Supabase] Booking saved successfully (camelCase) to '${tableName}':`, booking.referenceId);
          return { success: true, tableUsed: tableName, data: camelData };
        }
        lastError = error;
      } else {
        lastError = error;
      }
    } catch (err: any) {
      lastError = err;
    }
  }

  console.warn('[Supabase] Could not insert into candidate tables:', lastError?.message || lastError);
  return {
    success: false,
    error: lastError?.message || 'Supabase tables not initialized or schema not configured',
  };
}

/**
 * Checks connectivity and table status with the user's Supabase project.
 */
export async function testSupabaseConnection(): Promise<{
  connected: boolean;
  projectId: string;
  url: string;
  tables: {
    bookings: boolean;
    appointments: boolean;
  };
  error?: string;
}> {
  let bookingsOk = false;
  let appointmentsOk = false;
  let errorMsg: string | undefined = undefined;

  try {
    const { error: bErr } = await supabase.from('bookings').select('id').limit(1);
    if (!bErr || bErr.code !== 'PGRST205') {
      bookingsOk = true;
    }

    const { error: aErr } = await supabase.from('appointments').select('id').limit(1);
    if (!aErr || aErr.code !== 'PGRST205') {
      appointmentsOk = true;
    }

    if (!bookingsOk && !appointmentsOk && bErr) {
      errorMsg = bErr.message;
    }

    return {
      connected: true,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
      tables: {
        bookings: bookingsOk,
        appointments: appointmentsOk,
      },
      error: errorMsg,
    };
  } catch (err: any) {
    return {
      connected: false,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
      tables: {
        bookings: false,
        appointments: false,
      },
      error: err.message || 'Failed to connect to Supabase',
    };
  }
}
