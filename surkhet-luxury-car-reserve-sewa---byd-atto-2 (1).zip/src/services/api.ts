import {
  BookingItem,
  GalleryPhoto,
  ServiceRates,
  BusinessSettings,
  DashboardStats,
} from '../types/index.ts';

const TOKEN_KEY = 'surkhet_admin_jwt';

export function getStoredAdminToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredAdminToken(token: string | null): void {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

async function request<T>(
  url: string,
  options: RequestInit = {}
): Promise<{ success: boolean; data?: T; error?: string; [key: string]: any }> {
  const token = getStoredAdminToken();
  const headers: Record<string, string> = {
    Accept: 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  if (options.body && typeof options.body === 'string') {
    headers['Content-Type'] = 'application/json';
  }

  try {
    const res = await fetch(url, {
      ...options,
      headers,
    });

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      const text = await res.text();
      // Server returned HTML (e.g. 404/500/redirect to index.html)
      console.error(`Non-JSON response from ${url}:`, text.slice(0, 150));
      return {
        success: false,
        error: `API Server returned non-JSON (${res.status}). Ensure backend is running.`,
      };
    }

    const data = await res.json();
    if (!res.ok) {
      return {
        success: false,
        error: data.error || `HTTP error ${res.status}`,
        ...data,
      };
    }

    return data;
  } catch (err: any) {
    console.error(`Fetch failure for ${url}:`, err);
    return {
      success: false,
      error: err.message || 'Network connection failed',
    };
  }
}

export const api = {
  // Public APIs
  async getRates(): Promise<{ success: boolean; rates?: ServiceRates; error?: string }> {
    const res = await request<{ rates: ServiceRates }>('/api/rates');
    return { success: res.success, rates: res.rates, error: res.error };
  },

  async getGallery(): Promise<{ success: boolean; gallery?: GalleryPhoto[]; error?: string }> {
    const res = await request<{ gallery: GalleryPhoto[] }>('/api/gallery');
    return { success: res.success, gallery: res.gallery, error: res.error };
  },

  async getSettings(): Promise<{ success: boolean; settings?: BusinessSettings; error?: string }> {
    const res = await request<{ settings: BusinessSettings }>('/api/settings');
    return { success: res.success, settings: res.settings, error: res.error };
  },

  async submitBooking(payload: Partial<BookingItem>): Promise<{
    success: boolean;
    booking?: BookingItem;
    error?: string;
    message?: string;
  }> {
    const res = await request<{ booking: BookingItem; message: string }>('/api/bookings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return {
      success: res.success,
      booking: res.booking,
      error: res.error,
      message: res.message,
    };
  },

  // Admin Auth APIs
  async getSetupStatus(): Promise<{
    success: boolean;
    isConfigured?: boolean;
    hasActiveSlot?: boolean;
    activeUser?: string | null;
    error?: string;
  }> {
    return await request('/api/admin/setup-status');
  },

  async setupAdmin(
    username: string,
    password: string
  ): Promise<{ success: boolean; token?: string; username?: string; message?: string; error?: string }> {
    const res = await request<{ token?: string; username?: string }>('/api/admin/setup', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });

    if (res.success && res.token) {
      setStoredAdminToken(res.token);
    }
    return res;
  },

  async login(
    username: string,
    password: string,
    forceResetSlot = false
  ): Promise<{
    success: boolean;
    token?: string;
    username?: string;
    slotLocked?: boolean;
    error?: string;
  }> {
    const res = await request<{ token: string; username: string }>('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, forceResetSlot }),
    });

    if (res.success && res.token) {
      setStoredAdminToken(res.token);
    }
    return res;
  },

  async resetSlot(password?: string): Promise<{ success: boolean; message?: string; error?: string }> {
    return await request('/api/admin/reset-slot', {
      method: 'POST',
      body: JSON.stringify({ password }),
    });
  },

  async logout(): Promise<void> {
    try {
      await request('/api/admin/logout', { method: 'POST' });
    } finally {
      setStoredAdminToken(null);
    }
  },

  async getMe(): Promise<{ success: boolean; user?: { username: string }; error?: string }> {
    return await request('/api/admin/me');
  },

  // Admin Dashboard Data
  async getDashboardStats(): Promise<{
    success: boolean;
    stats?: DashboardStats;
    error?: string;
  }> {
    return await request('/api/admin/dashboard-stats');
  },

  async getBookings(): Promise<{ success: boolean; bookings?: BookingItem[]; error?: string }> {
    return await request('/api/admin/bookings');
  },

  async updateBooking(
    id: string,
    data: { status?: string; adminNotes?: string }
  ): Promise<{ success: boolean; booking?: BookingItem; error?: string }> {
    return await request(`/api/admin/bookings/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  },

  async deleteBooking(id: string): Promise<{ success: boolean; error?: string }> {
    return await request(`/api/admin/bookings/${id}`, {
      method: 'DELETE',
    });
  },

  // Admin Rates
  async getAdminRates(): Promise<{ success: boolean; rates?: ServiceRates; error?: string }> {
    return await request('/api/admin/rates');
  },

  async updateRates(
    rates: Partial<ServiceRates>
  ): Promise<{ success: boolean; rates?: ServiceRates; message?: string; error?: string }> {
    return await request('/api/admin/rates', {
      method: 'PUT',
      body: JSON.stringify(rates),
    });
  },

  async resetRates(): Promise<{ success: boolean; rates?: ServiceRates; message?: string; error?: string }> {
    return await request('/api/admin/rates/reset', {
      method: 'POST',
    });
  },

  // Admin Gallery (BYD ATTO 2 Only)
  async getAdminGallery(): Promise<{ success: boolean; gallery?: GalleryPhoto[]; error?: string }> {
    return await request('/api/admin/gallery');
  },

  async addGalleryPhoto(data: {
    title: string;
    imageUrl: string;
    category?: 'exterior' | 'interior' | 'feature' | 'event';
    caption?: string;
  }): Promise<{ success: boolean; photo?: GalleryPhoto; error?: string }> {
    return await request('/api/admin/gallery', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async deleteGalleryPhoto(id: string): Promise<{ success: boolean; error?: string }> {
    return await request(`/api/admin/gallery/${id}`, {
      method: 'DELETE',
    });
  },

  // Admin Settings & Password
  async getAdminSettings(): Promise<{ success: boolean; settings?: BusinessSettings; error?: string }> {
    return await request('/api/admin/settings');
  },

  async updateSettings(
    settings: Partial<BusinessSettings>
  ): Promise<{ success: boolean; settings?: BusinessSettings; message?: string; error?: string }> {
    return await request('/api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    });
  },

  async changePassword(
    currentPassword: string,
    newPassword: string
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    return await request('/api/admin/password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  },

  // Supabase Integration
  async getSupabaseStatus(): Promise<{ success: boolean; status?: any; error?: string }> {
    return await request('/api/admin/supabase-status');
  },

  async syncAllToSupabase(): Promise<{ success: boolean; totalBookings?: number; message?: string; error?: string }> {
    return await request('/api/admin/supabase-sync', {
      method: 'POST',
    });
  },
};
