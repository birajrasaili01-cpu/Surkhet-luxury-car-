import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { WhyChooseUs } from './components/WhyChooseUs.tsx';
import { OurCar } from './components/OurCar.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { PricingTable } from './components/PricingTable.tsx';
import { BookingForm } from './components/BookingForm.tsx';
import { GallerySection } from './components/GallerySection.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';
import { AdminLoginModal } from './components/admin/AdminLoginModal.tsx';
import { AdminDashboardModal } from './components/admin/AdminDashboardModal.tsx';
import { DEFAULT_RATES } from './utils/pricing.ts';
import { ServiceRates, GalleryPhoto, BusinessSettings, RoutePlan } from './types/index.ts';
import { INITIAL_BYD_GALLERY } from './constants/images.ts';
import { api, getStoredAdminToken } from './services/api.ts';
import { SafeLeftActions } from './components/SafeLeftActions.tsx';
import { Phone, Calendar } from 'lucide-react';

export default function App() {
  const [rates, setRates] = useState<ServiceRates>(DEFAULT_RATES);
  const [gallery, setGallery] = useState<GalleryPhoto[]>(INITIAL_BYD_GALLERY);
  const [settings, setSettings] = useState<BusinessSettings | undefined>(undefined);

  // Admin Auth States
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminLoginOpen, setAdminLoginOpen] = useState(false);
  const [adminDashboardOpen, setAdminDashboardOpen] = useState(false);

  // Quick booking trigger from service/pricing click
  const [activeBookingService, setActiveBookingService] = useState<string>('');
  const [activeBookingPlan, setActiveBookingPlan] = useState<RoutePlan>('one-way');

  const phone = settings?.phone || '9802581402';

  // Load initial data from backend API
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const [ratesRes, galleryRes, settingsRes] = await Promise.all([
          api.getRates(),
          api.getGallery(),
          api.getSettings(),
        ]);

        if (ratesRes.success && ratesRes.rates) {
          setRates(ratesRes.rates);
        }
        if (galleryRes.success && galleryRes.gallery) {
          setGallery(galleryRes.gallery);
        }
        if (settingsRes.success && settingsRes.settings) {
          setSettings(settingsRes.settings);
        }
      } catch (err) {
        console.error('Failed to load initial data:', err);
      }
    };

    fetchInitialData();

    // Check existing admin token
    const token = getStoredAdminToken();
    if (token) {
      api.getMe().then((res) => {
        if (res.success) {
          setIsAdminLoggedIn(true);
        }
      });
    }
  }, []);

  const scrollToBooking = () => {
    const el = document.getElementById('booking-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectService = (serviceId: string, plan: RoutePlan = 'one-way') => {
    setActiveBookingService(serviceId);
    setActiveBookingPlan(plan);
    scrollToBooking();
  };

  const handleAdminLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    setAdminLoginOpen(false);
    setAdminDashboardOpen(true);
  };

  const handleAdminLogout = async () => {
    await api.logout();
    setIsAdminLoggedIn(false);
    setAdminDashboardOpen(false);
  };

  const handleOpenAdmin = () => {
    if (isAdminLoggedIn) {
      setAdminDashboardOpen(true);
    } else {
      setAdminLoginOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] selection:bg-amber-100 selection:text-amber-900">
      {/* Clean White Sticky Header */}
      <Navbar
        settings={settings}
        onOpenBooking={scrollToBooking}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          settings={settings}
          onOpenBooking={scrollToBooking}
          onExploreRates={() => {
            const el = document.getElementById('pricing');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* 4. "हामीलाई नै किन रोज्ने?" Section (Exact Nepali Wording) */}
        <WhyChooseUs onBookNow={scrollToBooking} />

        {/* Dedicated "Our Car: BYD ATTO 2" Section */}
        <OurCar />

        {/* Public Services Section */}
        <ServicesSection
          rates={rates}
          onSelectService={(id) => handleSelectService(id, 'one-way')}
        />

        {/* Official Rates Breakdown Table */}
        <PricingTable
          rates={rates}
          onBookRoute={(id, plan) => handleSelectService(id, plan || 'one-way')}
        />

        {/* Central Booking Form Section */}
        <section className="py-16 sm:py-24 bg-gray-50/70 relative border-b border-gray-200">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <BookingForm
              rates={rates}
              initialServiceId={activeBookingService}
              initialPlan={activeBookingPlan}
            />
          </div>
        </section>

        {/* BYD ATTO 2 Gallery */}
        <GallerySection photos={gallery} />

        {/* About Section */}
        <AboutSection />

        {/* Contact Section */}
        <ContactSection settings={settings} />
      </main>

      {/* Clean Light Footer */}
      <Footer settings={settings} onOpenAdmin={handleOpenAdmin} />

      {/* Admin Login Modal */}
      <AdminLoginModal
        isOpen={adminLoginOpen}
        onClose={() => setAdminLoginOpen(false)}
        onLoginSuccess={handleAdminLoginSuccess}
      />

      {/* Admin Full Dashboard Modal */}
      <AdminDashboardModal
        isOpen={adminDashboardOpen}
        onClose={() => setAdminDashboardOpen(false)}
        onLogout={handleAdminLogout}
        currentRates={rates}
        onRatesUpdated={(newRates) => setRates(newRates)}
        onSettingsUpdated={(newSettings) => setSettings(newSettings)}
      />

      {/* Safe Left-Side Quick Contact and Booking Widget */}
      <SafeLeftActions phone={phone} onBookNow={scrollToBooking} />

      {/* Mobile Sticky Quick Action Bar with Safe Insets */}
      <div
        className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-gray-200 p-2.5 px-4 flex items-center justify-between gap-3 shadow-lg"
        style={{
          paddingBottom: 'max(0.625rem, calc(0.625rem + env(safe-area-inset-bottom, 0px)))',
          paddingLeft: 'max(1rem, env(safe-area-inset-left, 1rem))',
          paddingRight: 'max(1rem, env(safe-area-inset-right, 1rem))',
        }}
      >
        {/* Left Side: Ultra-Clear High-Quality Contact Call Button */}
        <a
          href={`tel:${phone.replace(/[^0-9]/g, '')}`}
          className="flex-1 py-3 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 active:from-amber-600 active:to-amber-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md active:scale-95 border border-amber-400/40 transition-all"
          title={`सिधा कल: ${phone}`}
        >
          <div className="w-5 h-5 rounded-md bg-white/20 flex items-center justify-center shrink-0">
            <Phone className="w-3.5 h-3.5 fill-current" />
          </div>
          <span className="font-['Outfit'] tracking-wider">{phone}</span>
        </a>

        {/* Right Side: High-Quality Car Booking Button */}
        <button
          onClick={scrollToBooking}
          className="flex-1 py-3 px-3 rounded-xl bg-gray-900 active:bg-black text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer border border-gray-800"
        >
          <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
          <span>कार रिजर्भ</span>
        </button>
      </div>
    </div>
  );
}
