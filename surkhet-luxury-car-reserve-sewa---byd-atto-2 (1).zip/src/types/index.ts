export type ServiceType = 'route' | 'per-day' | 'airport';

export type RoutePlan = 'one-way' | 'two-way';

export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';

export interface ServiceRates {
  nepalgunjOneWay: number; // 5000
  nepalgunjTwoWay: number; // 8000
  dailekhOneWay: number;   // 6000
  dailekhTwoWay: number;   // 8000
  dhargadhiOneWay: number; // 15000
  dhargadhiTwoWay: number; // 18000
  valleyTourPerDay: number;// 5000
  weddingReservePerDay: number; // 5000
  airportPickupDrop: number;    // 1000
}

export interface ServiceDefinition {
  id: string;
  titleNepali: string;
  titleEnglish: string;
  type: ServiceType;
  description: string;
  basePriceText: string;
  features: string[];
}

export interface BookingSelection {
  serviceId: string;
  routePlan?: RoutePlan;
  numberOfDays?: number;
}

export interface BookingItem {
  id: string;
  referenceId: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  serviceId: string;
  serviceName: string;
  tripType: string;
  routePlan?: RoutePlan;
  numberOfDays?: number;
  pickupDate: string;
  pickupTime: string;
  pickupLocation: string;
  dropLocation: string;
  passengerCount: number;
  specialRequests?: string;
  amount: number;
  status: BookingStatus;
  createdAt: string;
  adminNotes?: string;
}

export interface GalleryPhoto {
  id: string;
  title: string;
  category: 'exterior' | 'interior' | 'feature' | 'event';
  imageUrl: string;
  caption: string;
  isBydAtto2?: boolean;
  createdAt: string;
}

export interface BusinessSettings {
  businessNameNepali: string;
  businessNameEnglish: string;
  phone: string;
  altPhone?: string;
  email: string;
  address: string;
  whatsapp: string;
  facebookUrl: string;
  tiktokUrl: string;
  instagramUrl: string;
  tagline: string;
}

export interface AdminSession {
  username: string;
  token: string;
  loggedInAt: string;
}

export interface DashboardStats {
  totalBookings: number;
  pendingBookings: number;
  confirmedBookings: number;
  completedBookings: number;
  totalRevenue: number;
  galleryCount: number;
  activeSlotUser: string | null;
}
